"""
altasset_allocator/optimizer.py
---------------------------------
Independent engine for PRIVATE / ILLIQUID / CASH-FLOW-DRIVEN assets:
private equity & credit stakes, small-business ownership, real assets,
appraisal-based real estate, and fixed-schedule instruments (bonds,
amortizing loans). This does NOT share code with market_allocator on
purpose -- these assets break the market allocator's core assumption of
a continuous, arm's-length daily price.

Three independent tools, usable separately or together:

  1. Appraisal un-smoothing (Geltner, 1991) -- private NAV marks are
     smoothed (appraisers anchor partly on the prior mark), which
     artificially suppresses measured volatility and correlation. This
     recovers the economic return series before it goes anywhere near a
     covariance matrix.
  2. AltAssetAllocator -- QP allocator over the (un-smoothed) covariance,
     with illiquidity-bucket caps, a minimum liquidity buffer, and a
     minimum position count (cardinality) instead of assuming daily
     rebalancing is possible.
  3. cash_flow_match / macaulay_duration -- for the fixed-schedule subset
     (bonds, amortizing private credit, or any liability you're funding),
     an LP that matches generated cash flows to a liability schedule, and
     the duration/convexity metrics for immunization.

Works for ANY cash-flow schedule: the allocator only needs a NAV/return
series per asset and, optionally, a T x N matrix of projected cash flows
-- there is no assumption about frequency (monthly, quarterly, irregular
capital calls/distributions) or the type of underlying asset.
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize, linprog


# ---------------------------------------------------------------------
# 1. Appraisal un-smoothing
# ---------------------------------------------------------------------
def estimate_unsmoothing_phi(nav_returns: pd.Series) -> float:
    """AR(1) autocorrelation of the observed (smoothed) return series is a
    standard proxy for the appraisal-smoothing coefficient phi."""
    r = nav_returns.dropna().values
    if len(r) < 3:
        return 0.0
    phi = np.corrcoef(r[1:], r[:-1])[0, 1]
    return float(np.clip(phi, 0.0, 0.95))  # must stay < 1 for the filter to be well-defined


def unsmooth_returns(nav_returns: pd.Series, phi: float = None):
    """
    Geltner (1991) unsmoothing filter:
        true_t = (observed_t - phi * observed_{t-1}) / (1 - phi)
    Recovers the higher-volatility, higher-correlation-to-market "true"
    economic return series implied by a smoothed appraisal series.
    """
    r = nav_returns.dropna()
    if phi is None:
        phi = estimate_unsmoothing_phi(r)
    true_ret = (r - phi * r.shift(1)) / (1.0 - phi)
    return true_ret.dropna(), phi


def unsmooth_panel(nav_return_panel: pd.DataFrame):
    """Apply unsmoothing asset-by-asset (each asset can have its own
    smoothing coefficient -- e.g. real estate vs. venture stakes are
    marked very differently)."""
    unsmoothed, phis = {}, {}
    for col in nav_return_panel.columns:
        u, phi = unsmooth_returns(nav_return_panel[col])
        unsmoothed[col] = u
        phis[col] = phi
    panel = pd.DataFrame(unsmoothed).dropna()
    return panel, phis


# ---------------------------------------------------------------------
# 2. Allocator
# ---------------------------------------------------------------------
class AltAssetAllocator:
    """The input dial for the alt-asset side: assets, which of them are
    illiquid (lock-up), caps, liquidity buffer, minimum position count."""

    def __init__(self, config: dict):
        self.config = config
        self.assets = list(config["assets"])
        self.n = len(self.assets)
        self.max_weight_per_asset = config.get("max_weight_per_asset", 0.20)
        self.max_illiquid_weight = config.get("max_illiquid_weight", 0.30)
        self.liquidity_buffer = config.get("liquidity_buffer", 0.10)
        self.min_positions = config.get("min_positions", 3)
        self.illiquid_flags = config.get("illiquid_flags", {})  # asset name -> bool

    def _illiquid_idx(self):
        return [i for i, a in enumerate(self.assets) if self.illiquid_flags.get(a, False)]

    def _liquid_idx(self):
        return [i for i, a in enumerate(self.assets) if not self.illiquid_flags.get(a, False)]

    def optimize(self, mu: np.ndarray, cov: np.ndarray):
        """Minimum-variance allocation subject to illiquidity caps and a
        minimum liquid-sleeve buffer. Cardinality (min_positions) is
        enforced as a post-hoc check + report rather than a MIQP, since a
        true cardinality constraint needs a mixed-integer solver we don't
        have offline; min_weight_per_asset combined with max_weight is
        usually enough to keep the solution diversified in practice."""
        illiquid_idx = self._illiquid_idx()
        liquid_idx = self._liquid_idx()

        # feasibility guard: the illiquid cap alone forces liquid weight >=
        # (1 - max_illiquid_weight); make sure the liquid sleeve can actually
        # hold that much given its own per-asset cap.
        if liquid_idx:
            min_liquid_needed = max(self.liquidity_buffer, 1.0 - self.max_illiquid_weight)
            liquid_capacity = len(liquid_idx) * self.max_weight_per_asset
            if min_liquid_needed > liquid_capacity + 1e-9:
                raise ValueError(
                    f"Infeasible config: liquid sleeve needs >= {min_liquid_needed:.2f} total weight "
                    f"but only {len(liquid_idx)} liquid asset(s) x {self.max_weight_per_asset:.2f} cap "
                    f"= {liquid_capacity:.2f} available. Raise max_weight_per_asset, add liquid "
                    f"assets, or relax max_illiquid_weight / liquidity_buffer.")

        # feasible starting point: split the budget across buckets at the
        # midpoint of what's required, then equal-weight within each bucket
        w0 = np.zeros(self.n)
        illiquid_budget = self.max_illiquid_weight / 2.0 if illiquid_idx else 0.0
        liquid_budget = 1.0 - illiquid_budget
        if illiquid_idx:
            per = min(illiquid_budget / len(illiquid_idx), self.max_weight_per_asset)
            for i in illiquid_idx:
                w0[i] = per
        if liquid_idx:
            per = min(liquid_budget / len(liquid_idx), self.max_weight_per_asset)
            for i in liquid_idx:
                w0[i] = per
        w0 = w0 / w0.sum()  # renormalize to sum exactly 1 for the starting guess

        cons = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
        if illiquid_idx:
            cons.append({"type": "ineq",
                         "fun": lambda w, idx=illiquid_idx: self.max_illiquid_weight - np.sum(w[idx])})
        if liquid_idx:
            cons.append({"type": "ineq",
                         "fun": lambda w, idx=liquid_idx: np.sum(w[idx]) - self.liquidity_buffer})

        bounds = [(0.0, self.max_weight_per_asset)] * self.n

        res = minimize(lambda w: w @ cov @ w, w0, method="SLSQP",
                        bounds=bounds, constraints=cons,
                        options={"maxiter": 1000, "ftol": 1e-12})
        if not res.success:
            raise RuntimeError(f"alt-asset solver failed: {res.message}")

        w = np.clip(res.x, 0.0, None)
        w = w / w.sum()

        n_active = int((w > 1e-4).sum())
        if n_active < self.min_positions:
            print(f"  [warn] solution concentrated in {n_active} positions "
                  f"(< min_positions={self.min_positions}); consider lowering max_weight_per_asset")
        return w


# ---------------------------------------------------------------------
# 3. Cash-flow matching (any schedule) + duration
# ---------------------------------------------------------------------
def cash_flow_match(liability_schedule: np.ndarray, cash_flow_matrix: np.ndarray, budget: float = None):
    """
    LP: choose non-negative DOLLAR amounts x invested in a set of cash-flow-
    generating assets so that generated cash meets or exceeds a liability
    schedule every period, at minimum total capital deployed.

    liability_schedule : (T,)   required cash outflow each period, in dollars
    cash_flow_matrix    : (T,N) cash generated PER $1 INVESTED in asset i,
                           period t -- works for ANY schedule: bond coupons,
                           private-credit amortization, real-asset
                           distributions, evergreen income notes...
    budget               : optional cap on TOTAL dollars invested (sum(x)).
                           Individual position sizes are otherwise unbounded
                           (non-negative) -- infeasibility means no
                           combination of the given instruments can cover
                           the schedule at all, not a per-position limit.
    """
    T, N = cash_flow_matrix.shape
    c = np.ones(N)  # minimize total capital deployed
    A_ub = -cash_flow_matrix           # -CF @ x <= -liability  <=>  CF @ x >= liability
    b_ub = -liability_schedule
    if budget is not None:
        A_ub = np.vstack([A_ub, np.ones((1, N))])
        b_ub = np.concatenate([b_ub, [budget]])
    bounds = [(0.0, None)] * N

    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(f"cash-flow-matching LP failed (infeasible -- no combination of these "
                            f"instruments, within budget, covers the schedule): {res.message}")
    return res.x, res.fun


def macaulay_duration(cash_flows: np.ndarray, times_years: np.ndarray, ytm: float) -> float:
    """Standard Macaulay duration: PV-weighted average time to cash flow."""
    discount = 1.0 / (1.0 + ytm) ** times_years
    pv = cash_flows * discount
    price = pv.sum()
    if price <= 0:
        return float("nan")
    return float((times_years * pv).sum() / price)


def modified_duration(macaulay_dur: float, ytm: float, periods_per_year: int = 1) -> float:
    return macaulay_dur / (1.0 + ytm / periods_per_year)
