"""
altasset_allocator/demo.py
-----------------------------
Small end-to-end simulation for the PRIVATE / CASH-FLOW-DRIVEN allocator.

Story this demo tells:
  1. Private/illiquid assets get "appraisal smoothed" -- their reported
     NAV returns are a blend of the true economic return and last
     period's mark. This makes them look artificially low-vol and
     low-correlation to everything else ("free diversification" that
     isn't real).
  2. Un-smoothing (Geltner filter) recovers the true risk picture.
  3. Optimizing on the naive (smoothed) covariance vs. the unsmoothed
     covariance gives DIFFERENT weights -- the naive version typically
     over-allocates to illiquid assets because it underestimates their
     true risk and correlation to the liquid sleeve.
  4. A separate cash-flow-matching example (works for any schedule --
     bond coupons, private-credit amortization, business capex draws)
     and a duration calculation for the fixed-income-style piece.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import covariance as C
from common import risk as RISK
from altasset_allocator.optimizer import (
    AltAssetAllocator, unsmooth_panel, cash_flow_match, macaulay_duration, modified_duration
)

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")
os.makedirs(OUT, exist_ok=True)


def simulate_true_quarterly_returns(assets, n_quarters=32, seed=11):
    rng = np.random.default_rng(seed)
    n = len(assets)
    macro = rng.normal(0.012, 0.05, size=n_quarters)          # common macro/market factor
    loadings = rng.uniform(0.5, 1.1, size=n)                  # how exposed each asset is to it
    idio_vol = rng.uniform(0.03, 0.09, size=n)
    idio = rng.normal(0, 1, size=(n_quarters, n)) * idio_vol
    drift = rng.uniform(0.005, 0.02, size=n)
    true_ret = drift + np.outer(macro, loadings) + idio
    dates = pd.period_range("2017Q1", periods=n_quarters, freq="Q").to_timestamp()
    return pd.DataFrame(true_ret, index=dates, columns=assets)


def apply_appraisal_smoothing(true_ret: pd.Series, phi: float) -> pd.Series:
    """observed_t = phi * observed_{t-1} + (1-phi) * true_t -- the mechanism
    Geltner unsmoothing is designed to invert."""
    obs = true_ret.copy()
    for i in range(1, len(obs)):
        obs.iloc[i] = phi * obs.iloc[i - 1] + (1 - phi) * true_ret.iloc[i]
    return obs


def main():
    print("=" * 70)
    print("ALT-ASSET / CASH-FLOW ALLOCATOR DEMO (private & illiquid assets)")
    print("=" * 70)

    with open(os.path.join(os.path.dirname(__file__), "config.json")) as f:
        config = json.load(f)
    assets = config["assets"]
    illiquid_flags = config["illiquid_flags"]

    true_panel = simulate_true_quarterly_returns(assets)

    # true (appraiser-unknown) smoothing coefficients -- illiquid assets are
    # smoothed harder than liquid ones, which have phi ~ 0 (real market prices)
    true_phis = {"PRIVATE_EQUITY_FUND": 0.55, "PRIVATE_CREDIT_FUND": 0.45,
                 "REAL_ESTATE_NAV": 0.65, "SMALL_BIZ_STAKE_A": 0.50,
                 "SMALL_BIZ_STAKE_B": 0.50, "LIQUID_BOND_SLEEVE": 0.0,
                 "LIQUID_EQUITY_SLEEVE": 0.0}

    observed = pd.DataFrame({a: apply_appraisal_smoothing(true_panel[a], true_phis[a])
                              for a in assets})

    print(f"\nSimulated {len(assets)} assets x {len(true_panel)} quarters")
    print("Reported (appraisal-smoothed) vs. true annualized volatility:")
    for a in assets:
        obs_vol = observed[a].std() * np.sqrt(4)
        true_vol = true_panel[a].std() * np.sqrt(4)
        tag = "illiquid" if illiquid_flags.get(a) else "liquid"
        print(f"  {a:<22} [{tag:<8}] reported={obs_vol*100:5.1f}%   true={true_vol*100:5.1f}%")

    # ---- Stage 2 (this engine's version): unsmooth, then clean covariance ----
    unsmoothed, est_phis = unsmooth_panel(observed)
    print("\nEstimated smoothing coefficients (phi) from reported data alone:")
    for a in assets:
        print(f"  {a:<22} est. phi={est_phis[a]:.2f}   (true phi was {true_phis[a]:.2f})")

    cov_naive = C.nearest_psd(C.sample_covariance(observed))
    cov_unsmoothed = C.nearest_psd(C.sample_covariance(unsmoothed))
    mu_naive = observed.mean().values * 4
    mu_unsmoothed = unsmoothed.mean().values * 4

    print("\nPairwise correlation, illiquid assets vs LIQUID_EQUITY_SLEEVE:")
    eq_idx = assets.index("LIQUID_EQUITY_SLEEVE")
    corr_naive = observed.corr().values
    corr_un = unsmoothed.corr().values
    for i, a in enumerate(assets):
        if illiquid_flags.get(a):
            print(f"  {a:<22} naive corr={corr_naive[i, eq_idx]:+.2f}   "
                  f"unsmoothed corr={corr_un[i, eq_idx]:+.2f}")

    # ---- Stage 4: optimize on naive vs unsmoothed covariance ----
    allocator = AltAssetAllocator(config)
    w_naive = allocator.optimize(mu_naive, cov_naive)
    w_unsmoothed = allocator.optimize(mu_unsmoothed, cov_unsmoothed)

    print(f"\n{'Asset':<22}{'Naive weight':>14}{'Unsmoothed weight':>20}{'Difference':>13}")
    for a, wn, wu in zip(assets, w_naive, w_unsmoothed):
        print(f"{a:<22}{wn*100:13.1f}%{wu*100:19.1f}%{(wu-wn)*100:+12.1f}%")

    illiq_idx = [i for i, a in enumerate(assets) if illiquid_flags.get(a)]
    illiq_naive_total = w_naive[illiq_idx].sum()
    illiq_unsmoothed_total = w_unsmoothed[illiq_idx].sum()
    print(f"\n  Total illiquid allocation -- naive: {illiq_naive_total*100:.1f}%   "
          f"unsmoothed: {illiq_unsmoothed_total*100:.1f}%  "
          f"(cap = {config['max_illiquid_weight']*100:.0f}%)")
    if abs(illiq_naive_total - illiq_unsmoothed_total) > 1e-3:
        print("  Unsmoothing changed the TOTAL amount the optimizer is willing to put in illiquid\n"
              "  assets -- the naive run was leaning on understated risk to justify a bigger sleeve.")
    else:
        print("  Both runs hit the illiquid cap, so the total didn't move -- but look at WHICH\n"
              "  illiquid assets got the allocation: unsmoothing exposed PRIVATE_EQUITY_FUND's true\n"
              "  (higher) risk and correlation to the liquid sleeve, so capital rotated toward the\n"
              "  asset whose true diversification benefit actually held up.")

    # ---- Stage 5: risk attribution on the (correct) unsmoothed portfolio ----
    report = RISK.risk_attribution_report(w_unsmoothed, cov_unsmoothed, assets)
    print(f"\n[Risk attribution] unsmoothed portfolio vol = {report['_portfolio_vol']*100:.1f}%")
    for a in assets:
        d = report[a]
        print(f"  {a:<22} weight={d['weight']*100:5.1f}%  risk share={d['pct_of_total_risk']*100:5.1f}%")

    # ------------------------------------------------------------------
    # Cash-flow matching: works for ANY schedule (bond coupons, private-
    # credit amortization, capex draws -- here, a small business needs
    # capital every quarter for 2 years).
    # ------------------------------------------------------------------
    print("\n" + "-" * 70)
    print("CASH-FLOW MATCHING (any schedule) -- funding a small-business capex plan")
    liability_schedule = np.array([50_000, 50_000, 60_000, 60_000,
                                    70_000, 70_000, 80_000, 80_000])  # 8 quarters
    # two funding instruments; entries are cash generated PER $1 INVESTED in
    # that period, so decision variables come out directly in dollars invested
    quarters = np.arange(1, 9)
    note_a = np.full(8, 0.06)                         # evergreen note: 6% cash yield every quarter
    note_b = np.where(quarters == 8, 1.30, 0.0)        # zero-coupon note: 30% total return, at Q8 only
    cash_flow_matrix = np.column_stack([note_a, note_b])

    invested, capital_deployed = cash_flow_match(liability_schedule, cash_flow_matrix, budget=3_000_000)
    generated = cash_flow_matrix @ invested
    print(f"  Capital invested -- Note A (evergreen, 6%/qtr): ${invested[0]:,.0f}, "
          f"Note B (zero-coupon, matures Q8): ${invested[1]:,.0f}")
    print(f"  Total capital deployed: ${capital_deployed:,.0f}")
    print(f"  {'Quarter':<10}{'Required':>12}{'Generated':>14}{'Surplus':>12}")
    for q, req, gen in zip(quarters, liability_schedule, generated):
        print(f"  Q{q:<9}{req:>12,.0f}{gen:>14,.0f}{gen-req:>12,.0f}")

    # ------------------------------------------------------------------
    # Duration / immunization example
    # ------------------------------------------------------------------
    print("\n" + "-" * 70)
    print("DURATION / IMMUNIZATION -- 5yr, 6% annual-coupon bond, par $1,000, ytm=5%")
    times = np.arange(1, 6)
    cfs = np.array([60, 60, 60, 60, 1060])
    mac_dur = macaulay_duration(cfs, times, ytm=0.05)
    mod_dur = modified_duration(mac_dur, ytm=0.05, periods_per_year=1)
    print(f"  Macaulay duration: {mac_dur:.2f} years")
    print(f"  Modified duration: {mod_dur:.2f}  (~% price move per 1% yield move)")

    # ---------------- plots ----------------
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    im0 = axes[0].imshow(corr_naive, cmap="Reds", vmin=-1, vmax=1)
    axes[0].set_title("Correlation heat-rating -- NAIVE (appraisal-smoothed)")
    axes[0].set_xticks(range(len(assets))); axes[0].set_xticklabels(assets, rotation=90, fontsize=7)
    axes[0].set_yticks(range(len(assets))); axes[0].set_yticklabels(assets, fontsize=7)

    im1 = axes[1].imshow(corr_un, cmap="Reds", vmin=-1, vmax=1)
    axes[1].set_title("Correlation heat-rating -- UNSMOOTHED (true)")
    axes[1].set_xticks(range(len(assets))); axes[1].set_xticklabels(assets, rotation=90, fontsize=7)
    axes[1].set_yticks(range(len(assets))); axes[1].set_yticklabels([], fontsize=7)
    fig.colorbar(im1, ax=axes[1], label="pairwise correlation")

    fig.tight_layout()
    out_path = os.path.join(OUT, "altasset_allocator_demo.png")
    fig.savefig(out_path, dpi=140)
    print(f"\nSaved chart: {out_path}")

    # ---- correctness verification ----
    sums_ok = abs(w_naive.sum() - 1.0) < 1e-6 and abs(w_unsmoothed.sum() - 1.0) < 1e-6
    psd_ok = (np.linalg.eigvalsh(cov_naive)[0] > -1e-8) and (np.linalg.eigvalsh(cov_unsmoothed)[0] > -1e-8)
    cf_ok = bool(np.all(generated >= liability_schedule - 1e-6))
    print(f"\n[Verification] both weight vectors sum to 1.0: {sums_ok}")
    print(f"[Verification] both covariance matrices are PSD: {psd_ok}")
    print(f"[Verification] cash-flow schedule fully covered every quarter: {cf_ok}")

    return w_naive, w_unsmoothed


if __name__ == "__main__":
    main()
