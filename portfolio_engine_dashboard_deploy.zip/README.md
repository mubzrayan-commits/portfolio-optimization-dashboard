# Portfolio Optimization Engine

Two **independent** allocators sharing one common math layer, exactly as
requested: one for liquid/efficient markets (stocks, ETFs, exchange-traded
bonds), one for private/illiquid/cash-flow-driven assets (PE, private
credit, real estate, small-business stakes). They don't call into each
other -- they share `common/` because return math, covariance cleaning,
and risk attribution are the same mathematics regardless of asset class,
but the *objective* and *constraints* are genuinely different per class,
which is why they're separate engines rather than one allocator with a
flag.

```
portfolio_engine/
├── common/
│   ├── returns.py       Stage 1 -- log/arithmetic/total returns + self-check
│   ├── data_quality.py   Stage 0 -- alignment, missing data, stale prices, outliers
│   ├── covariance.py    Stage 2 -- RMT (Marchenko-Pastur) + Ledoit-Wolf cleaning
│   ├── robust.py          Michaud resampling -- damps estimation-noise instability
│   ├── risk.py           Stage 5 -- marginal/component risk attribution
│   └── backtest.py       Stages 4-5 -- walk-forward engine, transaction costs
├── market_allocator/      ENGINE 1 -- liquid / efficient markets
│   ├── optimizer.py       min-variance, target-return, max-Sharpe, min-CVaR
│   ├── black_litterman.py  fundamental (FCF-yield) views → forward-looking returns
│   ├── config.json         <- the "input dial": edit this, not the code
│   ├── demo.py              40-asset synthetic backtest, RMT vs Ledoit-Wolf vs sample
│   ├── black_litterman_demo.py  equilibrium prior + FCF view, honest OOS comparison
│   └── robustness_demo.py   mu churn + turnover, real walk-forward, "does it collapse?"
├── altasset_allocator/    ENGINE 2 -- private / illiquid / cash-flow assets
│   ├── optimizer.py       appraisal un-smoothing, illiquidity caps, cash-flow LP, duration
│   ├── config.json         <- the input dial for this engine
│   └── demo.py              7-asset simulation: smoothed vs unsmoothed risk + allocation
├── schedule_runner.py      cron-ready entry point + a stdlib long-running loop
├── data_quality_demo.py    Stage 0 demo -- injects bad data, shows it getting caught
└── outputs/                 charts + rebalance log land here
```

## Stage map (what the brief asked for -> where it lives)

| Stage | File | Method |
|---|---|---|
| 0. Data optimization | `common/data_quality.py` | business-day alignment check, missing-data gap analysis, stale-price detection, return-outlier flagging (catches unadjusted splits) -- see `data_quality_demo.py` |
| 1. Ingestion & return mapping | `common/returns.py` | `R = ln(P_t/P_t-1)`, arithmetic conversion, `self_check()` proves time-additivity and round-trips exactly |
| Fundamental data → forward returns | `market_allocator/black_litterman.py` | reverse-optimized equilibrium prior + an FCF-yield cross-sectional view, blended via Black-Litterman -- see `black_litterman_demo.py` |
| 2. Covariance cleaning | `common/covariance.py` | Marchenko-Pastur RMT denoising **and** Ledoit-Wolf shrinkage, both PSD-projected |
| 3. Objective & constraints | `*_allocator/optimizer.py` | min-variance, target-return, max-Sharpe (frontier sweep), min-CVaR (Rockafellar-Uryasev LP); fully-invested, long-only, sector/illiquidity caps |
| 4. Solve | same | `scipy.optimize` -- SLSQP for the QPs, `linprog(method="highs")` for the LPs |
| Robustness (does it hold up live?) | `common/robust.py` | Michaud resampling to damp corner-solution instability; equilibrium-anchored mu as a stable alternative to the noisy trailing mean -- see `robustness_demo.py` |
| 5. Risk attribution | `common/risk.py` | exact Euler decomposition of portfolio vol into per-asset marginal/component contribution |

**Solver note:** the brief listed CVXPY/Gurobi/scipy.optimize as
acceptable solvers. This environment has no internet access (so CVXPY
couldn't be installed), so everything runs on `scipy.optimize`, which is
in the same list and is a genuine convex solver (SLSQP for QP, HiGHS for
LP) -- not a heuristic substitute. If you have CVXPY available locally,
`optimizer.py`'s `optimize()` methods are drop-in replaceable with a
CVXPY formulation; the math (objective + constraints) is unchanged.

## Run it

```bash
pip install numpy pandas scipy scikit-learn matplotlib   # everything else is stdlib
python data_quality_demo.py                        # Stage 0 -- injects bad data, shows it getting caught
python market_allocator/demo.py                     # Engine 1 demo + chart
python market_allocator/black_litterman_demo.py     # fundamental (FCF-yield) → forward returns
python market_allocator/robustness_demo.py           # does it hold up live? mu churn + turnover, real walk-forward
python altasset_allocator/demo.py                   # Engine 2 demo + chart
python schedule_runner.py --engine market      # one rebalance cycle, cron-ready
python schedule_runner.py --engine altasset
```

## Why this shouldn't collapse in live markets

The single biggest reason a backtested optimizer disappoints live isn't a
math error -- it's "error maximization": point-estimate mean-variance
optimization doesn't just use your return estimates, it actively hunts for
whichever assets your estimation NOISE happened to flatter, then bets
heavily on them. `robustness_demo.py` measures this directly on a real
walk-forward run (37 monthly rebalances, not one lucky split):

- The trailing-mean return estimate itself changes ~62% (L1) from one
  rebalance to the next; the equilibrium-anchored estimate changes ~9% --
  it's a function of the covariance matrix and market weights, not a
  noisy rolling sample mean.
- That input instability shows up directly as turnover: ~0.29x per
  rebalance for the naive historical-mean portfolio vs ~0.03x for the
  equilibrium-anchored one -- turnover is a transaction-cost bill a flat-
  bps backtest assumption usually understates.
- Michaud resampling (`common/robust.py`) -- bootstrap the return history,
  re-solve many times, average the weights -- doesn't fix noisy inputs,
  but damps the optimizer's tendency to convert that noise into a full
  corner-solution swing (turnover 0.25x vs 0.29x here, and a meaningfully
  more diversified result: effective N 19 vs 16).

None of this claims equilibrium-anchored returns are "more profitable" in
general -- only that they're structurally more stable. Whether tilting
away from equilibrium pays off depends on whether your view (fundamental
data, a signal, a forecast) carries real information, which is exactly
what `black_litterman_demo.py` tests separately, holding everything else
fixed.

## The "input dial" -- adapting to your own assets

Each engine's `config.json` is the only thing you should need to touch to
repoint it at a different universe:

```json
{
  "assets": ["...", "..."],
  "max_weight_per_asset": 0.20,
  "objective": "min_variance"
}
```
Change the asset list, caps, or objective; the code (`optimizer.py`) is
generic over whatever list you provide. `market_allocator/config.json`
additionally supports `sector_map`/`sector_caps`; `altasset_allocator/
config.json` supports `illiquid_flags`/`max_illiquid_weight`/
`liquidity_buffer`/`min_positions`.

## Plugging in real data

Both `demo.py` files generate synthetic data because this sandbox has no
network access. To go live, replace exactly one function:

- **Market engine**: swap `market_allocator/demo.py::simulate_market_prices()`
  for a real adjusted-close pull -- `yfinance.download(tickers, period="5y",
  auto_adjust=True)`, or a broker/vendor API. Must return a DataFrame:
  index=dates, columns=tickers, values=adjusted close prices.
- **Alt-asset engine**: swap `altasset_allocator/demo.py::simulate_true_quarterly_returns()`
  + the smoothing step for your actual NAV statements / fund administrator
  feed. `unsmooth_panel()` and the allocator work unchanged on real data --
  they only need a NAV return time series per asset.
- **Risk-free rate**: `market_allocator/config.json["risk_free_rate"]` --
  point this at the current T-Bill yield matching your rebalance horizon.

`schedule_runner.py` has `# <-- swap this` markers at the two data-loading
functions -- that's the only file a production deployment needs to edit
beyond the config JSONs.

## Where to actually run this

- **Backtesting/research**: this repo as-is, or port the strategy into
  [QuantConnect](https://www.quantconnect.com) / `backtrader` /
  `zipline-reloaded` for point-in-time survivorship-bias-free data and
  richer execution simulation.
- **Live execution (public markets)**: [Alpaca](https://alpaca.markets)
  (commission-free, paper-trading sandbox, Python SDK) or Interactive
  Brokers (`ib_insync`) for order routing once `MarketAllocator.optimize()`
  hands you target weights.
- **Scheduling**: cron (shown above) is enough for a always-on Linux
  box/VM; for cloud-native, AWS EventBridge + Lambda, GCP Cloud Scheduler
  + Cloud Functions, or Airflow if you already run it, all just need to
  call `schedule_runner.py`'s `run_rebalance()`.
- **Dashboard / monitoring**: Streamlit or Dash wrap the `performance_summary()`
  and `risk_attribution_report()` outputs into a live view with almost no
  extra code.
- **Alt-asset / cash-flow engine**: there's no exchange to route orders
  to here -- this typically runs on a monthly/quarterly cron alongside
  your fund administrator's NAV cadence, feeding a portfolio-accounting
  system or simply an internal report.

## Honesty check on the demo numbers

The market-allocator demo prints a t-stat on mean returns specifically so
you don't mistake noise for a "statistical edge" -- with a short lookback
window, expected-return estimates are themselves noisy (the classic
"risk is estimable, return isn't" problem), so a Sharpe improvement of a
few hundredths in one backtest window is not proof of anything. Re-run
`market_allocator/demo.py` with different `seed` values in
`simulate_market_prices()` to see how much the ranking moves around --
that instability *is* the honest answer to "does this have a real edge."
