"""
market_allocator/black_litterman_demo.py
--------------------------------------------
Completes Part 2 of the brief: turns fundamental data (free-cash-flow
yield) into forward-looking expected returns via Black-Litterman, then
runs an HONEST out-of-sample test of whether that actually beats the
naive alternative (trailing historical mean) -- holding the covariance
matrix, allocator, and constraints identical across both, so the only
thing being tested is the quality of the expected-return estimate.

The FCF-yield signal here is deliberately built to correlate with the
(constant, throughout the simulation) true drift used to generate the
synthetic prices -- exactly the situation a real fundamental signal is
in: noisy, but with genuine information the trailing sample mean
struggles to extract from a short window.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import returns as R
from common import covariance as C
from common import backtest as BT
from market_allocator.optimizer import MarketAllocator
from market_allocator.demo import simulate_market_prices
from market_allocator import black_litterman as BL

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")
os.makedirs(OUT, exist_ok=True)


def main():
    print("=" * 70)
    print("BLACK-LITTERMAN / FUNDAMENTAL-DATA DEMO (Part 2 of the brief)")
    print("=" * 70)

    prices, true_drift = simulate_market_prices(return_drift=True)
    assets = list(prices.columns)
    n = len(assets)
    log_ret = R.log_returns(prices)

    lookback = 400  # fundamental views are slow-moving; use a longer in-sample window
    window = log_ret.iloc[:lookback]
    oos = log_ret.iloc[lookback:]
    print(f"\nIn-sample window: {lookback} days. Out-of-sample: {len(oos)} days.")

    cov = C.nearest_psd(C.rmt_denoise(window)) * 252

    # synthetic market-cap weights: current market consensus, independent of
    # our future-return simulation (real caps aren't correlated with your views either)
    rng = np.random.default_rng(99)
    raw_caps = rng.lognormal(mean=0, sigma=1.0, size=n)
    market_weights = raw_caps / raw_caps.sum()

    # ---- Step 1: reverse-optimize the equilibrium prior ----
    delta = 2.5
    pi = BL.implied_equilibrium_returns(cov, market_weights, delta=delta)
    max_err = BL.verify_reverse_optimization(cov, market_weights, pi)
    print(f"\n[Verification] reverse-optimization identity (Sigma^-1 Pi ∝ w_mkt): "
          f"max weight error = {max_err:.2e}  (should be ~0)")

    # ---- Step 2: build a fundamental (FCF-yield) view ----
    # simulate FCF yields correlated with true (constant) drift, plus noise --
    # this is what makes it a genuine but imperfect signal, like real fundamentals
    rng2 = np.random.default_rng(123)
    annual_drift = true_drift.values * 252
    fcf_yield = 0.06 + (annual_drift - annual_drift.mean()) * 3.0 + rng2.normal(0, 0.15, size=n)
    signal_corr = np.corrcoef(fcf_yield, annual_drift)[0, 1]
    print(f"\nSimulated FCF-yield signal, correlation with TRUE drift: {signal_corr:.2f} "
          f"(deliberately imperfect -- a real fundamental signal is a noisy predictor, not a lookup table)")

    P, Q, Omega, top_idx, bottom_idx = BL.fcf_yield_views(
        fcf_yield, n_quantiles=5, spread_view=0.04, view_confidence=0.6)
    print(f"View: top-quintile FCF yield ({len(top_idx)} assets) outperforms "
          f"bottom-quintile ({len(bottom_idx)} assets) by {Q[0]*100:.1f}%/yr, "
          f"confidence=0.6")

    # ---- Step 3: blend ----
    mu_bl = BL.black_litterman_blend(cov, pi, P, Q, Omega, tau=0.05)
    mu_hist = window.mean().values * 252

    print(f"\n{'Asset':<12}{'FCF yield':>11}{'Pi (prior)':>12}{'Hist. mean':>12}{'BL blend':>12}")
    show_idx = list(top_idx[-3:]) + list(bottom_idx[:3])
    for i in show_idx:
        tag = "[TOP FCF]" if i in top_idx else "[BOTTOM FCF]"
        print(f"{assets[i]:<12}{fcf_yield[i]*100:>10.1f}%{pi[i]*100:>11.1f}%"
              f"{mu_hist[i]*100:>11.1f}%{mu_bl[i]*100:>11.1f}%  {tag}")
    print("  Note how BL sits between Pi and the view -- pulled toward the view only for the\n"
          "  ranked assets, and only as far as view_confidence justifies -- while the historical\n"
          "  mean swings around with much less structure (short-window noise).")

    # ---- Step 4: does it actually help, out-of-sample? ----
    with open(os.path.join(os.path.dirname(__file__), "config.json")) as f:
        config = json.load(f)
    config["assets"] = assets
    config["sector_map"], config["sector_caps"] = {}, {}
    config["max_weight_per_asset"] = 0.08
    config["objective"] = "max_sharpe"

    candidates = {
        "market_cap_weight": market_weights,
        "equal_weight": np.ones(n) / n,
        "equilibrium_only (Pi)": MarketAllocator(config).optimize(pi, cov),
        "historical_mean": MarketAllocator(config).optimize(mu_hist, cov),
        "black_litterman": MarketAllocator(config).optimize(mu_bl, cov),
    }

    print(f"\n[Out-of-sample results, {len(oos)} days, no rebalancing -- isolates the mu estimate]")
    print(f"{'Strategy':<24}{'AnnRet':>9}{'AnnVol':>9}{'Sharpe':>9}{'t-stat':>9}")
    oos_perf = {}
    for name, w in candidates.items():
        port_ret = pd.Series(oos.values @ w, index=oos.index)
        perf = BT.performance_summary(port_ret, risk_free_rate=config.get("risk_free_rate", 0.0))
        oos_perf[name] = perf
        print(f"{name:<24}{perf['annualized_return']*100:>8.2f}%{perf['annualized_vol']*100:>8.2f}%"
              f"{perf['sharpe_ratio']:>9.2f}{perf['t_stat_mean_return']:>9.2f}")

    best = max(oos_perf, key=lambda k: oos_perf[k]["sharpe_ratio"])
    print(f"\n  Best out-of-sample Sharpe: '{best}'")
    print("  Notice black_litterman and equilibrium_only landed close together -- the 8%-per-asset\n"
          "  cap limits how much any single view can move the total portfolio, even when it moves\n"
          "  individual expected returns a lot (see the table above). That's the constraint working\n"
          "  as intended, not the view failing.\n"
          "  This is also a single simulated draw, not a law of nature -- re-run with a different\n"
          "  seed in simulate_market_prices() to see how much this ranking moves around. The\n"
          "  honest takeaway is structural, not this specific number: Black-Litterman can only\n"
          "  help if the fundamental view carries real signal (built in on purpose here) -- with a\n"
          "  genuinely uninformative view it just tracks the equilibrium prior, which is by design\n"
          "  safer than trusting a noisy historical mean.")

    # ---------------- plot ----------------
    fig, ax = plt.subplots(figsize=(8, 5))
    for name, w in candidates.items():
        cum = np.exp((oos.values @ w).cumsum())
        ax.plot(oos.index, cum, label=name)
    ax.set_title("Out-of-sample growth of $1, by expected-return estimate\n(same covariance & allocator for every line)")
    ax.legend(fontsize=8)
    ax.set_ylabel("Growth of $1")
    fig.tight_layout()
    out_path = os.path.join(OUT, "black_litterman_demo.png")
    fig.savefig(out_path, dpi=140)
    print(f"\nSaved chart: {out_path}")

    return oos_perf


if __name__ == "__main__":
    main()
