"""
market_allocator/black_litterman.py
--------------------------------------
Part 2's "Fundamental and Structural Alternatives" turned into code. Raw
cash-flow statements can't go into a variance optimizer directly (they're
accounting data, not a return series) -- Black-Litterman is the standard
bridge: it blends a market-equilibrium PRIOR with VIEWS built from
fundamental data (free-cash-flow yield here; the mechanism is generic to
any cross-sectional signal) into a single, more stable set of expected
returns. This replaces noisy trailing-mean estimates with something that
actually uses valuation information, and -- critically -- only moves away
from equilibrium where you actually have a view and are confident in it.

Reference formulation (He & Litterman, 1999):
  1. Reverse-optimize the market-cap-weighted portfolio for the IMPLIED
     equilibrium returns:
         Pi = delta * Sigma * w_mkt
     (delta = market risk-aversion coefficient)
  2. Express views as (P, Q, Omega):
         P (K x N)     -- which assets each of the K views involves
         Q (K,)        -- the view's expected return
         Omega (K x K) -- confidence in each view (diagonal = view variance;
                          smaller = more confident = pulls harder)
  3. Blend:
         M     = [(tau*Sigma)^-1 + P' Omega^-1 P]^-1
         mu_BL = M @ [(tau*Sigma)^-1 @ Pi + P' @ Omega^-1 @ Q]
"""
import numpy as np


def implied_equilibrium_returns(cov: np.ndarray, market_weights: np.ndarray, delta: float = 2.5) -> np.ndarray:
    """Pi = delta * Sigma * w_mkt -- 'what expected returns would make the
    market's current cap-weighted portfolio the optimal one', the standard
    BL starting prior. delta ~2.5-3.0 is a typical market risk-aversion
    estimate (higher = more risk-averse market)."""
    return delta * (cov @ market_weights)


def fcf_yield_views(fcf_yields: np.ndarray, n_quantiles: int = 5,
                     spread_view: float = 0.04, view_confidence: float = 0.5):
    """
    Builds ONE relative view from cross-sectional free-cash-flow yield:
    "the equal-weighted top FCF-yield quintile outperforms the equal-
    weighted bottom FCF-yield quintile by `spread_view` per year." This is
    the brief's "rank assets by FCF-to-Price to build a cross-sectional
    model" idea, expressed as a Black-Litterman view instead of a
    separate scoring model that would need its own optimizer.

    view_confidence in (0, 1]: higher = more confident = smaller view
    variance = the view pulls the posterior harder.

    Returns (P, Q, Omega, top_idx, bottom_idx).
    """
    n = len(fcf_yields)
    order = np.argsort(fcf_yields)
    q = max(1, n // n_quantiles)
    bottom_idx, top_idx = order[:q], order[-q:]

    p_row = np.zeros(n)
    p_row[top_idx] = 1.0 / len(top_idx)
    p_row[bottom_idx] = -1.0 / len(bottom_idx)
    P = p_row.reshape(1, -1)
    Q = np.array([spread_view])

    view_confidence = float(np.clip(view_confidence, 1e-3, 1.0))
    view_variance = (1.0 - view_confidence) * 0.05 + 1e-6
    Omega = np.array([[view_variance]])
    return P, Q, Omega, top_idx, bottom_idx


def black_litterman_blend(cov: np.ndarray, pi: np.ndarray, P: np.ndarray, Q: np.ndarray,
                           Omega: np.ndarray, tau: float = 0.05) -> np.ndarray:
    """Standard BL posterior expected-return blend (closed form)."""
    tau_sigma_inv = np.linalg.inv(tau * cov)
    omega_inv = np.linalg.inv(Omega)
    M = np.linalg.inv(tau_sigma_inv + P.T @ omega_inv @ P)
    return M @ (tau_sigma_inv @ pi + P.T @ omega_inv @ Q)


def verify_reverse_optimization(cov: np.ndarray, market_weights: np.ndarray, pi: np.ndarray,
                                 tol: float = 1e-6) -> float:
    """
    Correctness check on the BL identity itself: for an UNCONSTRAINED
    (budget-only) mean-variance problem, the optimal weights are
    proportional to Sigma^-1 @ mu. Since Pi was built as
    Pi = delta * Sigma @ w_mkt, we have Sigma^-1 @ Pi = delta * w_mkt, so
    normalizing recovers w_mkt EXACTLY (independent of delta). This proves
    the reverse-optimization step is internally consistent before any
    view is blended in -- if this doesn't hold, something upstream (cov,
    weights, or Pi) is wrong.

    Returns the max absolute weight error; raises if it exceeds `tol`.
    """
    w_recovered = np.linalg.solve(cov, pi)
    w_recovered = w_recovered / w_recovered.sum()
    max_err = float(np.max(np.abs(w_recovered - market_weights)))
    if max_err > tol:
        raise AssertionError(f"reverse-optimization identity broke: max weight error {max_err:.2e}")
    return max_err
