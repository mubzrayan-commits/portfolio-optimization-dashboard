"""
market_allocator/demo.py
--------------------------
Small end-to-end simulation for the LIQUID-MARKETS allocator.

Deliberately uses N=40 assets against a T=126-day (6-month) lookback window
(N/T ~ 0.32) -- large enough that the raw sample covariance is visibly
noisy, so the RMT-cleaning stage actually has something to clean, mirroring
the "N approaches T" failure mode the brief calls out.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import returns as R
from common import covariance as C
from common import risk as RISK
from common import backtest as BT
from market_allocator.optimizer import MarketAllocator

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")
os.makedirs(OUT, exist_ok=True)


def simulate_market_prices(n_assets=40, n_days=900, n_factors=4, seed=7, return_drift=False):
    """3-4 latent macro factors drive correlation; each asset also carries
    idiosyncratic noise. This gives a realistic-ish correlation structure
    with a handful of dominant ('signal') eigenvalues and a bulk of noise
    eigenvalues -- exactly what RMT cleaning is designed to separate.

    return_drift=True also returns the per-asset annual drift used to
    generate the data -- used by black_litterman_demo.py to build a
    fundamental signal that has genuine (if noisy) correlation with true
    forward returns, the way real FCF-yield data sometimes does."""
    rng = np.random.default_rng(seed)
    loadings = rng.normal(0.5, 0.35, size=(n_assets, n_factors))
    factor_ret = rng.normal(0.0002, 0.010, size=(n_days, n_factors))
    idio_vol = rng.uniform(0.010, 0.022, size=n_assets)
    idio_ret = rng.normal(0, 1, size=(n_days, n_assets)) * idio_vol
    drift = rng.uniform(0.0001, 0.0005, size=n_assets)

    log_rets = drift + factor_ret @ loadings.T + idio_ret
    prices = 100 * np.exp(np.cumsum(log_rets, axis=0))
    dates = pd.bdate_range("2021-01-04", periods=n_days)
    names = [f"ASSET_{i+1:02d}" for i in range(n_assets)]
    prices_df = pd.DataFrame(prices, index=dates, columns=names)
    if return_drift:
        return prices_df, pd.Series(drift, index=names)
    return prices_df


def main():
    print("=" * 70)
    print("MARKET ALLOCATOR DEMO (liquid / efficient-market assets)")
    print("=" * 70)

    prices = simulate_market_prices()
    print(f"\nSimulated {prices.shape[1]} assets x {prices.shape[0]} trading days")

    # ---- Stage 0/1: data optimization -- verify the panel is safe before
    #      any return/covariance math touches it (see data_quality_demo.py
    #      for what happens when it ISN'T clean) ----
    from common import data_quality as DQ
    dq_report = DQ.data_quality_report(prices, verbose=False)
    print(f"[Stage 0] Data quality check: {'PASS' if dq_report['is_clean'] else 'ISSUES FOUND'} "
          f"({prices.shape[1]} assets x {prices.shape[0]} dates, aligned business-day panel)")

    # ---- Stage 1: verify the return math is exactly correct ----
    R.self_check(prices)

    log_ret = R.log_returns(prices)

    # ---- Stage 2: show what RMT cleaning actually does on this data ----
    lookback = 126
    window = log_ret.iloc[:lookback]
    cov_raw = C.nearest_psd(C.sample_covariance(window))
    cov_rmt, diag = C.rmt_denoise(window, return_diagnostics=True)
    cov_lw, shrinkage = C.ledoit_wolf_shrinkage(window)

    print(f"\n[Stage 2] Covariance cleaning diagnostics (N={diag['n_assets']}, T={diag['n_obs']}, "
          f"q=N/T={diag['q_ratio']:.3f})")
    print(f"  Marchenko-Pastur noise band: [{diag['lambda_minus']:.3f}, {diag['lambda_plus']:.3f}]")
    print(f"  {diag['n_noise_eigenvalues']} of {diag['n_assets']} eigenvalues classified as noise "
          f"and shrunk to their average")
    print(f"  Condition number -- raw sample cov: {C.condition_number(cov_raw):.1f}")
    print(f"  Condition number -- RMT-cleaned cov: {C.condition_number(cov_rmt):.1f}")
    print(f"  Condition number -- Ledoit-Wolf cov: {C.condition_number(cov_lw):.1f}")
    print(f"  Ledoit-Wolf shrinkage intensity: {shrinkage:.3f}")

    # ---- Stage 3/4: load the adaptable config, run three covariance methods
    #      through the SAME allocator + backtest engine, plus a benchmark ----
    with open(os.path.join(os.path.dirname(__file__), "config.json")) as f:
        base_config = json.load(f)
    base_config["assets"] = list(prices.columns)          # sync to simulated universe
    base_config["sector_map"] = {}                        # no sectors on synthetic names
    base_config["sector_caps"] = {}
    base_config["max_weight_per_asset"] = 0.08             # 40 assets -> tighter cap

    results = {}
    for method in ["rmt", "ledoit_wolf", "sample"]:
        cfg = dict(base_config)
        allocator = MarketAllocator(cfg)
        port_ret, w_hist, diags = BT.rolling_backtest(
            prices, allocator, lookback=lookback, rebalance_freq=21,
            transaction_cost_bps=10, cov_method=method)
        perf = BT.performance_summary(port_ret, risk_free_rate=base_config["risk_free_rate"])
        results[method] = {"returns": port_ret, "weights": w_hist, "perf": perf}

    # also try the max-Sharpe objective on top of RMT cleaning, for comparison
    cfg_ms = dict(base_config); cfg_ms["objective"] = "max_sharpe"
    allocator_ms = MarketAllocator(cfg_ms)
    ms_ret, ms_w_hist, _ = BT.rolling_backtest(prices, allocator_ms, lookback=lookback,
                                                rebalance_freq=21, transaction_cost_bps=10,
                                                cov_method="rmt")
    ms_perf = BT.performance_summary(ms_ret, risk_free_rate=base_config["risk_free_rate"])
    results["rmt_max_sharpe"] = {"returns": ms_ret, "weights": ms_w_hist, "perf": ms_perf}

    bench_ret = BT.equal_weight_benchmark(prices, lookback=lookback)
    bench_perf = BT.performance_summary(bench_ret, risk_free_rate=base_config["risk_free_rate"])

    print("\n[Stage 4] Backtest results, monthly rebalance, 10bps transaction cost")
    print(f"{'Strategy':<20}{'AnnRet':>9}{'AnnVol':>9}{'Sharpe':>9}{'MaxDD':>9}{'t-stat':>9}")
    for method, r in results.items():
        p = r["perf"]
        print(f"{method:<20}{p['annualized_return']*100:>8.2f}%{p['annualized_vol']*100:>8.2f}%"
              f"{p['sharpe_ratio']:>9.2f}{p['max_drawdown']*100:>8.2f}%{p['t_stat_mean_return']:>9.2f}")
    print(f"{'equal_weight':<20}{bench_perf['annualized_return']*100:>8.2f}%"
          f"{bench_perf['annualized_vol']*100:>8.2f}%{bench_perf['sharpe_ratio']:>9.2f}"
          f"{bench_perf['max_drawdown']*100:>8.2f}%{bench_perf['t_stat_mean_return']:>9.2f}")

    best = max(results, key=lambda m: results[m]["perf"]["sharpe_ratio"])
    edge_vs_bench = results[best]["perf"]["sharpe_ratio"] - bench_perf["sharpe_ratio"]
    print(f"\n  Best strategy by out-of-sample Sharpe: '{best}' "
          f"({edge_vs_bench:+.2f} Sharpe vs. equal-weight)")
    print("  Note: min-variance objectives intentionally ignore expected return and often trail\n"
          "  equal-weight on Sharpe in a single backtest window -- that's the known cost of variance-\n"
          "  only optimization, not a bug. max_sharpe/CVaR objectives (also implemented) use mu, and\n"
          "  mu estimated from a short lookback is itself noisy -- this is why the report above\n"
          "  prints a t-stat: to flag when an apparent 'edge' isn't statistically distinguishable\n"
          "  from zero.")

    # ---- Stage 5: risk attribution on the final RMT portfolio ----
    last_date, last_w = results["rmt"]["weights"][-1]
    final_window = log_ret.loc[:last_date].iloc[-lookback:]
    final_cov = C.rmt_denoise(final_window) * 252
    report = RISK.risk_attribution_report(last_w, final_cov, base_config["assets"])
    top5 = sorted(
        ((k, v) for k, v in report.items() if k != "_portfolio_vol"),
        key=lambda kv: kv[1]["pct_of_total_risk"], reverse=True
    )[:5]
    print(f"\n[Stage 5] Risk attribution, latest rebalance ({last_date.date()}), "
          f"portfolio vol = {report['_portfolio_vol']*100:.2f}%")
    print("  Top 5 risk contributors:")
    for name, d in top5:
        print(f"    {name}: weight={d['weight']*100:5.2f}%  "
              f"risk share={d['pct_of_total_risk']*100:5.2f}%")

    # ---------------- plots ----------------
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    for method, r in results.items():
        cum = np.exp(r["returns"].cumsum())
        axes[0].plot(cum.index, cum.values, label=method)
    cum_bench = np.exp(bench_ret.cumsum())
    axes[0].plot(cum_bench.index, cum_bench.values, label="equal_weight", linestyle="--", color="gray")
    axes[0].set_title("Cumulative growth of $1 (out-of-sample, walk-forward)")
    axes[0].legend()
    axes[0].set_ylabel("Growth of $1")

    # "red heat" risk/correlation rating -- darker red = higher pairwise correlation risk
    corr = final_window.corr().values
    im = axes[1].imshow(corr, cmap="Reds", vmin=0, vmax=1)
    axes[1].set_title("Correlation heat-rating (RMT lookback window)")
    fig.colorbar(im, ax=axes[1], label="pairwise correlation")
    axes[1].set_xticks([]); axes[1].set_yticks([])

    fig.tight_layout()
    out_path = os.path.join(OUT, "market_allocator_demo.png")
    fig.savefig(out_path, dpi=140)
    print(f"\nSaved chart: {out_path}")

    # ---- correctness verification (not just "it ran" -- it's mathematically valid) ----
    all_sum_to_one = all(
        abs(w.sum() - 1.0) < 1e-6 for r in results.values() for _, w in r["weights"]
    )
    all_psd = all(
        np.linalg.eigvalsh(C.rmt_denoise(log_ret.iloc[i - lookback:i]))[0] > -1e-8
        for i in range(lookback, len(log_ret), 63)  # spot-check every ~quarter
    )
    print(f"\n[Verification] every rebalance's weights sum to 1.0: {all_sum_to_one}")
    print(f"[Verification] every spot-checked RMT covariance is PSD: {all_psd}")

    return results, bench_perf


if __name__ == "__main__":
    main()
