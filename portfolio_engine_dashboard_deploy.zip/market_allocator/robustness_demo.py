"""
market_allocator/robustness_demo.py
---------------------------------------
Directly tests the concern "will this collapse in real markets?" rather
than just asserting an answer, using the REAL walk-forward run (not a
synthetic toy shock) across three ways of estimating mu:

  - historical   : trailing-window sample mean (the classic noisy estimate)
  - equilibrium  : Black-Litterman prior, Pi = delta*Sigma@w_mkt -- a
                    function of the covariance matrix and (slow-moving)
                    market weights, not of the noisy trailing return sample
  - resampled    : historical mu, but each rebalance is solved via Michaud
                    resampling (common/robust.py) instead of a single
                    point-estimate solve

Two things get measured, both from the SAME real backtest, across every
rebalance (not one lucky split):

  1. How much does the return ESTIMATE itself move from one rebalance to
     the next? (period-over-period change in mu)
  2. How much does the resulting PORTFOLIO move? (turnover)

These should be causally linked: an estimate that swings around a lot
forces the optimizer to keep re-fighting yesterday's noise, which shows
up directly as turnover -- and turnover you pay for in real slippage that
a backtest's flat bps assumption understates.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import returns as R
from common import backtest as BT
from common import robust as RB
from market_allocator.optimizer import MarketAllocator
from market_allocator.demo import simulate_market_prices

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")
os.makedirs(OUT, exist_ok=True)


def mu_period_over_period_change(diagnostics):
    """Average relative L1 change in mu between consecutive rebalances --
    a direct, real (not synthetic) measure of how noisy the return
    estimate itself is in practice."""
    changes = []
    for i in range(1, len(diagnostics)):
        prev_mu, cur_mu = diagnostics[i - 1]["mu"], diagnostics[i]["mu"]
        rel_change = np.abs(cur_mu - prev_mu).sum() / max(np.abs(prev_mu).sum(), 1e-9)
        changes.append(rel_change)
    return float(np.mean(changes)) if changes else float("nan")


def main():
    print("=" * 70)
    print("ROBUSTNESS DEMO -- does this fall apart on noise, not just backtest well?")
    print("=" * 70)

    prices = simulate_market_prices()
    assets = list(prices.columns)
    n = len(assets)

    with open(os.path.join(os.path.dirname(__file__), "config.json")) as f:
        base_config = json.load(f)
    base_config["assets"] = assets
    base_config["sector_map"], base_config["sector_caps"] = {}, {}
    base_config["max_weight_per_asset"] = 0.08
    base_config["objective"] = "target_return_min_var"  # single solve, genuinely mu-sensitive
    base_config["target_return"] = None                 # dynamic target = mean(mu) each call
    allocator = MarketAllocator(base_config)
    market_weights = np.ones(n) / n  # stand-in for real market caps -- see README

    lookback = 126
    print(f"\nFull walk-forward backtest, monthly rebalance, {lookback}-day lookback,\n"
          f"every rebalance counted (not a single train/test split), 3 mu estimation methods.")

    runs = {}
    runs["historical"] = BT.rolling_backtest(prices, allocator, lookback=lookback,
                                              cov_method="rmt", mu_method="historical")
    runs["equilibrium"] = BT.rolling_backtest(prices, allocator, lookback=lookback,
                                               cov_method="rmt", mu_method="equilibrium",
                                               market_weights=market_weights)
    runs["resampled"] = BT.rolling_backtest(prices, allocator, lookback=lookback,
                                             cov_method="rmt", mu_method="historical",
                                             use_resampling=True, n_resamples=40, seed=2)

    print(f"\n{'Method':<14}{'mu churn/rebal':>15}{'AvgTurnover':>13}{'AvgEffN':>10}"
          f"{'AnnRet':>9}{'Sharpe':>9}{'t-stat':>9}")
    summary = {}
    for name, (ret, wh, diag) in runs.items():
        mu_churn = mu_period_over_period_change(diag)
        avg_turnover = float(np.mean([d["turnover"] for d in diag]))
        avg_effn = float(np.mean([d["effective_n"] for d in diag]))
        perf = BT.performance_summary(ret, risk_free_rate=base_config["risk_free_rate"])
        summary[name] = {"mu_churn": mu_churn, "avg_turnover": avg_turnover,
                          "avg_effn": avg_effn, **perf}
        print(f"{name:<14}{mu_churn*100:>14.1f}%{avg_turnover:>12.2f}x{avg_effn:>10.1f}"
              f"{perf['annualized_return']*100:>8.1f}%{perf['sharpe_ratio']:>9.2f}"
              f"{perf['t_stat_mean_return']:>9.2f}")

    hist_churn, eq_churn = summary["historical"]["mu_churn"], summary["equilibrium"]["mu_churn"]
    hist_to = summary["historical"]["avg_turnover"]
    eq_to = summary["equilibrium"]["avg_turnover"]
    print(f"\n  'mu churn/rebal' = average relative change in the expected-return ESTIMATE from\n"
          f"  one rebalance to the next. Historical mu churned {hist_churn/max(eq_churn,1e-9):.1f}x\n"
          f"  more than equilibrium mu -- and that instability in the INPUT shows up directly as\n"
          f"  {hist_to/max(eq_to,1e-9):.1f}x more portfolio turnover downstream. AvgTurnover is total\n"
          f"  one-way weight change per rebalance (2.0x = a full portfolio swap); every bit of it\n"
          f"  is a transaction-cost bill a backtest's flat bps estimate usually understates.\n"
          f"  Resampling (same noisy historical mu, but averaged over {40} bootstrap re-solves per\n"
          f"  rebalance) doesn't fix the input noise, but it damps the optimizer's tendency to\n"
          f"  convert that noise into a full corner-solution swing -- turnover "
          f"{summary['resampled']['avg_turnover']:.2f}x vs historical's {hist_to:.2f}x.")

    print("\n  None of this says 'equilibrium mu is more profitable' in any universal sense -- it\n"
          "  says the equilibrium ESTIMATE is more stable, which is a real, structural property\n"
          "  (Pi depends on Sigma and weights, not a rolling sample mean), not a backtest artifact.\n"
          "  Whether that translates to better realized returns depends on whether your views/data\n"
          "  add real signal on top of it -- exactly what black_litterman_demo.py tests separately.")

    # ---------------- plot ----------------
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for name, (ret, wh, diag) in runs.items():
        cum = np.exp(ret.cumsum())
        axes[0].plot(cum.index, cum.values, label=name)
    axes[0].set_title("Cumulative growth (full walk-forward)")
    axes[0].legend()

    for name, (ret, wh, diag) in runs.items():
        turnovers = [d["turnover"] for d in diag]
        axes[1].plot(range(len(turnovers)), turnovers, marker="o", markersize=3, label=name)
    axes[1].set_title("Turnover per rebalance")
    axes[1].set_xlabel("rebalance #")
    axes[1].legend()

    fig.tight_layout()
    out_path = os.path.join(OUT, "robustness_demo.png")
    fig.savefig(out_path, dpi=140)
    print(f"\nSaved chart: {out_path}")

    return summary


if __name__ == "__main__":
    main()
