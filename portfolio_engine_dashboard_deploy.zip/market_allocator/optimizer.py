"""
market_allocator/optimizer.py
------------------------------
Stages 3-4 for LIQUID / EFFICIENT-MARKET assets (public equities, ETFs,
exchange-traded bonds, futures -- anything with a continuous daily price
series). This is the "known assets" engine.

Solver note: this environment has no internet access, so instead of
CVXPY/Gurobi we use scipy.optimize -- which the source brief explicitly
lists as an acceptable convex solver. SLSQP handles the quadratic (mean-
variance) programs; linprog(method="highs") handles the CVaR linear
program (Rockafellar-Uryasev formulation). Both are genuine convex
programs, not heuristics.

THE "INPUT DIAL": everything that changes per-use-case lives in a single
config dict (see config.json) -- the asset universe, weight bounds,
sector caps, objective type, target return, risk-free rate. Swap the
config, not the code.
"""
import numpy as np
from scipy.optimize import minimize, linprog


class MarketAllocator:
    def __init__(self, config: dict):
        self.config = config
        self.assets = list(config["assets"])
        self.n = len(self.assets)
        self.max_weight = config.get("max_weight_per_asset", 0.35)
        self.min_weight = config.get("min_weight_per_asset", 0.0)
        self.long_only = config.get("long_only", True)
        self.target_return = config.get("target_return", None)
        self.objective_type = config.get("objective", "min_variance")
        self.risk_free_rate = config.get("risk_free_rate", 0.0)
        self.sector_map = config.get("sector_map", {})
        self.sector_caps = config.get("sector_caps", {})

    # ---------- shared plumbing ----------
    def _bounds(self):
        lb = self.min_weight if self.long_only else -1.0
        return [(lb, self.max_weight)] * self.n

    def _sector_constraints(self):
        cons = []
        for sector, cap in self.sector_caps.items():
            idx = [i for i, a in enumerate(self.assets) if self.sector_map.get(a) == sector]
            if idx:
                cons.append({"type": "ineq",
                             "fun": (lambda w, idx=idx, cap=cap: cap - np.sum(w[idx]))})
        return cons

    # ---------- QP objectives (SLSQP) ----------
    def _solve_min_variance(self, mu: np.ndarray, cov: np.ndarray, target_return=None):
        w0 = np.ones(self.n) / self.n
        cons = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}] + self._sector_constraints()
        if target_return is not None:
            cons.append({"type": "ineq", "fun": lambda w: mu @ w - target_return})

        res = minimize(lambda w: w @ cov @ w, w0, method="SLSQP",
                        bounds=self._bounds(), constraints=cons,
                        options={"maxiter": 1000, "ftol": 1e-12})
        if not res.success:
            raise RuntimeError(f"min-variance solver failed: {res.message}")
        w = np.clip(res.x, 0.0 if self.long_only else -1.0, None)
        return w / w.sum()

    def _solve_max_sharpe(self, mu: np.ndarray, cov: np.ndarray, n_points: int = 40):
        """Sweep the efficient frontier (min-variance at each target return)
        and keep the point with the best Sharpe ratio. Robust to bound/
        sector constraints, unlike the classic quadratic-form normalization
        trick, which breaks once inequality bounds are present."""
        lo, hi = float(mu.min()), float(mu.max())
        targets = np.linspace(lo, hi, n_points)
        best_sharpe, best_w = -np.inf, None
        for t in targets:
            try:
                w = self._solve_min_variance(mu, cov, target_return=t)
                vol = np.sqrt(w @ cov @ w)
                if vol < 1e-12:
                    continue
                sharpe = (mu @ w - self.risk_free_rate) / vol
                if sharpe > best_sharpe:
                    best_sharpe, best_w = sharpe, w
            except RuntimeError:
                continue
        if best_w is None:
            raise RuntimeError("max-Sharpe sweep found no feasible portfolio")
        return best_w

    # ---------- CVaR objective (LP, Rockafellar-Uryasev) ----------
    def _solve_min_cvar(self, scenario_returns: np.ndarray, mu: np.ndarray,
                         beta: float = 0.95, target_return=None):
        """
        min  alpha + 1/((1-beta)T) * sum(u_t)
        s.t. u_t >= -R_t.w - alpha,  u_t >= 0,  sum(w) = 1,  bounds, [mu.w >= target]
        Variables stacked as x = [w (n) | alpha (1) | u (T)]
        """
        T, n = scenario_returns.shape
        c = np.concatenate([np.zeros(n), [1.0], np.ones(T) / ((1 - beta) * T)])

        A1 = np.hstack([-scenario_returns, -np.ones((T, 1)), -np.eye(T)])
        b1 = np.zeros(T)
        A_ub = A1
        b_ub = b1

        if target_return is not None:
            A_extra = np.hstack([-mu.reshape(1, -1), [[0.0]], np.zeros((1, T))])
            A_ub = np.vstack([A_ub, A_extra])
            b_ub = np.concatenate([b_ub, [-target_return]])

        A_eq = np.hstack([np.ones((1, n)), [[0.0]], np.zeros((1, T))])
        b_eq = [1.0]

        lb_w = self.min_weight if self.long_only else -1.0
        bounds = [(lb_w, self.max_weight)] * n + [(None, None)] + [(0.0, None)] * T

        res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                       bounds=bounds, method="highs")
        if not res.success:
            raise RuntimeError(f"CVaR LP failed: {res.message}")
        w = np.clip(res.x[:n], 0.0 if self.long_only else -1.0, None)
        return w / w.sum()

    # ---------- dispatcher ----------
    def optimize(self, mu: np.ndarray, cov: np.ndarray, scenario_returns: np.ndarray = None):
        if self.objective_type == "min_variance":
            return self._solve_min_variance(mu, cov)
        elif self.objective_type == "target_return_min_var":
            target = self.target_return if self.target_return is not None else float(np.mean(mu))
            return self._solve_min_variance(mu, cov, target_return=target)
        elif self.objective_type == "max_sharpe":
            return self._solve_max_sharpe(mu, cov)
        elif self.objective_type == "min_cvar":
            if scenario_returns is None:
                raise ValueError("min_cvar objective requires scenario_returns (raw return history)")
            return self._solve_min_cvar(scenario_returns, mu, target_return=self.target_return)
        else:
            raise ValueError(f"Unknown objective type: {self.objective_type}")
