import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from common import returns as R
from common import covariance as C
from common import risk as Risk
from common.backtest import rolling_backtest, performance_summary, equal_weight_benchmark
from market_allocator.optimizer import MarketAllocator

st.set_page_config(page_title="Portfolio Optimization Engine", page_icon="📊", layout="wide")

st.title("Portfolio Optimization Engine")
st.caption("Market allocation • covariance cleaning • risk attribution • walk-forward backtesting")

with st.sidebar:
    st.header("1. Data")
    uploaded = st.file_uploader("Upload price CSV", type=["csv"])
    demo = st.checkbox("Use demo data", value=uploaded is None)
    st.header("2. Optimization")
    objective = st.selectbox("Objective", ["min_variance", "max_sharpe", "target_return_min_var", "min_cvar"])
    max_weight = st.slider("Max weight / asset", 0.05, 1.0, 0.20, 0.01)
    rf = st.number_input("Risk-free rate", min_value=-0.10, max_value=0.30, value=0.02, step=0.005, format="%.3f")
    target_return = None
    if objective == "target_return_min_var":
        target_return = st.number_input("Target annual return", min_value=-0.50, max_value=1.0, value=0.10, step=0.01, format="%.2f")
    cov_method = st.selectbox("Covariance cleaning", ["rmt", "ledoit_wolf", "sample"])
    mu_method = st.selectbox("Expected-return method", ["historical", "equilibrium"])
    lookback = st.number_input("Lookback (days)", 30, 2000, 126, 1)
    rebalance = st.number_input("Rebalance frequency (days)", 1, 252, 21, 1)
    cost_bps = st.number_input("Transaction cost (bps)", 0.0, 500.0, 10.0, 1.0)
    run = st.button("Run optimization", type="primary", use_container_width=True)


def make_demo_prices(n_assets=10, n_days=700, seed=7):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=n_days)
    factors = rng.normal(0, 0.008, size=(n_days, 3))
    loadings = rng.normal(0, 0.7, size=(3, n_assets))
    idio = rng.normal(0, 0.012, size=(n_days, n_assets))
    ret = factors @ loadings + idio
    ret -= ret.mean(axis=0) - rng.normal(0.0003, 0.0001, n_assets)
    prices = 100 * np.exp(np.cumsum(ret, axis=0))
    return pd.DataFrame(prices, index=dates, columns=[f"ASSET_{i:02d}" for i in range(1, n_assets + 1)])


def load_prices():
    if uploaded is not None and not demo:
        df = pd.read_csv(uploaded)
        date_col = next((c for c in df.columns if c.lower() in {"date", "datetime", "timestamp"}), df.columns[0])
        df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
        df = df.dropna(subset=[date_col]).set_index(date_col)
        for c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df = df.dropna(axis=1, how="all").sort_index().dropna(how="all")
        if df.shape[1] < 2:
            raise ValueError("CSV needs at least two numeric asset columns.")
        return df.ffill().dropna()
    return make_demo_prices()

try:
    prices = load_prices()
except Exception as e:
    st.error(str(e))
    st.stop()

if prices.shape[0] < lookback + 5:
    st.warning(f"Only {len(prices)} price observations are available; increase the data history or reduce the lookback.")

# Data quality
st.subheader("Data")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Assets", prices.shape[1])
c2.metric("Observations", prices.shape[0])
c3.metric("Start", prices.index.min().strftime("%Y-%m-%d"))
c4.metric("End", prices.index.max().strftime("%Y-%m-%d"))

with st.expander("Price data", expanded=False):
    st.dataframe(prices.tail(20), use_container_width=True)

if not run and "results" not in st.session_state:
    st.info("Set the controls in the sidebar and press **Run optimization**.")
    st.stop()

if run:
    assets = list(prices.columns)
    config = {
        "assets": assets,
        "max_weight_per_asset": max_weight,
        "min_weight_per_asset": 0.0,
        "long_only": True,
        "objective": objective,
        "target_return": target_return,
        "risk_free_rate": rf,
    }
    allocator = MarketAllocator(config)
    try:
        log_ret = R.log_returns(prices)
        window = log_ret.iloc[-int(lookback):]
        if cov_method == "rmt":
            cov, cov_diag = C.rmt_denoise(window, return_diagnostics=True)
        elif cov_method == "ledoit_wolf":
            cov, shrink = C.ledoit_wolf_shrinkage(window)
            cov_diag = {"shrinkage": shrink}
        else:
            cov = C.nearest_psd(C.sample_covariance(window))
            cov_diag = {}
        cov_annual = cov * 252
        if mu_method == "historical":
            mu = window.mean().values * 252
        else:
            from market_allocator.black_litterman import implied_equilibrium_returns
            mu = implied_equilibrium_returns(cov_annual, np.ones(len(assets)) / len(assets))
        scenario = window.values if objective == "min_cvar" else None
        weights = allocator.optimize(mu, cov_annual, scenario_returns=scenario)
        risk = Risk.risk_attribution_report(weights, cov_annual, assets)
        port_vol = risk["_portfolio_vol"]
        st.session_state.results = dict(prices=prices, weights=weights, mu=mu, cov=cov_annual, cov_diag=cov_diag, risk=risk, port_vol=port_vol, config=config)
    except Exception as e:
        st.error(f"Optimization failed: {e}")
        st.stop()

res = st.session_state.results
weights = res["weights"]
assets = list(res["prices"].columns)

st.subheader("Optimized Portfolio")
a, b, c, d = st.columns(4)
a.metric("Expected return", f"{res['mu'] @ weights:.2%}")
b.metric("Portfolio volatility", f"{res['port_vol']:.2%}")
c.metric("Effective positions", f"{1 / np.sum(weights ** 2):.1f}")
d.metric("Largest weight", f"{weights.max():.2%}")

left, right = st.columns(2)
with left:
    wdf = pd.DataFrame({"Asset": assets, "Weight": weights}).sort_values("Weight", ascending=False)
    st.dataframe(wdf.style.format({"Weight": "{:.2%}"}), use_container_width=True, hide_index=True)
with right:
    st.bar_chart(wdf.set_index("Asset")["Weight"])

st.subheader("Risk Attribution")
rdf = pd.DataFrame([
    {"Asset": a, "Weight": res["risk"][a]["weight"], "Risk contribution": res["risk"][a]["risk_contribution"], "% of total risk": res["risk"][a]["pct_of_total_risk"]}
    for a in assets
]).sort_values("% of total risk", ascending=False)
st.dataframe(rdf.style.format({"Weight": "{:.2%}", "Risk contribution": "{:.2%}", "% of total risk": "{:.2%}"}), use_container_width=True, hide_index=True)

st.subheader("Walk-Forward Backtest")
try:
    bt, wh, diagnostics = rolling_backtest(
        prices, MarketAllocator(res["config"]), lookback=int(lookback), rebalance_freq=int(rebalance),
        transaction_cost_bps=float(cost_bps), cov_method=cov_method, mu_method=mu_method
    )
    summary = performance_summary(bt, risk_free_rate=rf)
    bench = equal_weight_benchmark(prices, lookback=int(lookback))
    eq = np.exp(bt.cumsum())
    bench_eq = np.exp(bench.reindex(bt.index).fillna(0).cumsum())
    p1, p2, p3, p4 = st.columns(4)
    p1.metric("Backtest return", f"{summary['total_return']:.2%}")
    p2.metric("Annualized return", f"{summary['annualized_return']:.2%}")
    p3.metric("Sharpe", f"{summary['sharpe_ratio']:.2f}")
    p4.metric("Max drawdown", f"{summary['max_drawdown']:.2%}")
    curve = pd.DataFrame({"Optimized": eq, "Equal weight": bench_eq})
    st.line_chart(curve)
    diag_df = pd.DataFrame(diagnostics)
    if not diag_df.empty:
        cols = [c for c in ["date", "turnover", "cost_drag", "effective_n", "condition_number"] if c in diag_df.columns]
        st.dataframe(diag_df[cols].tail(20), use_container_width=True, hide_index=True)
except Exception as e:
    st.warning(f"Backtest could not run with the current settings: {e}")

with st.expander("Engine diagnostics"):
    st.json({k: v for k, v in res["cov_diag"].items() if np.isscalar(v)})
