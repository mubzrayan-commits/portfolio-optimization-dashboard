"""
common/risk.py
---------------
Stage 5: Post-Trade Risk Attribution.

Decomposes total portfolio volatility into each asset's contribution, using
the standard Euler decomposition (exact because portfolio vol is
homogeneous of degree 1 in the weights):

    sigma_p           = sqrt(w' Sigma w)
    MCR_i (marginal)  = (Sigma w)_i / sigma_p
    CCR_i (component) = w_i * MCR_i          -- sums exactly to sigma_p
    %CCR_i            = CCR_i / sigma_p      -- sums exactly to 1.0
"""
import numpy as np


def portfolio_vol(weights: np.ndarray, cov: np.ndarray) -> float:
    return float(np.sqrt(weights @ cov @ weights))


def marginal_contribution_to_risk(weights: np.ndarray, cov: np.ndarray) -> np.ndarray:
    sigma_p = portfolio_vol(weights, cov)
    if sigma_p < 1e-14:
        return np.zeros_like(weights)
    return (cov @ weights) / sigma_p


def component_contribution_to_risk(weights: np.ndarray, cov: np.ndarray) -> np.ndarray:
    mcr = marginal_contribution_to_risk(weights, cov)
    return weights * mcr  # sums to sigma_p exactly


def risk_attribution_report(weights: np.ndarray, cov: np.ndarray, asset_names) -> dict:
    sigma_p = portfolio_vol(weights, cov)
    ccr = component_contribution_to_risk(weights, cov)
    pct = ccr / sigma_p if sigma_p > 1e-14 else np.zeros_like(ccr)
    report = {
        name: {
            "weight": float(w),
            "risk_contribution": float(c),
            "pct_of_total_risk": float(p),
        }
        for name, w, c, p in zip(asset_names, weights, ccr, pct)
    }
    report["_portfolio_vol"] = sigma_p
    return report
