"""
common/data_quality.py
------------------------
"Data optimization" -- Stage 1's debug checklist made concrete: turning raw,
possibly-messy price data into a clean, aligned panel BEFORE it ever reaches
return calculation or covariance cleaning. Garbage into Stage 1 becomes
garbage in the covariance matrix no matter how good the RMT cleaning is
downstream -- this stage exists so that never happens silently.

Four checks, each independently useful:
  1. Alignment / synchronization  -- do all assets share the same dates,
     at the frequency you think they do?
  2. Missing data                 -- gaps, and how long each one runs.
  3. Stale prices                 -- long runs of an unchanged price,
     usually a halted or illiquid feed rather than a flat market.
  4. Return outliers               -- single-day moves so extreme they're
     more likely a bad print or an unadjusted split/spinoff than a real
     move (this is exactly the "adjusted for corporate actions" warning
     from the brief, turned into an automatic check instead of a hope).
"""
import numpy as np
import pandas as pd


def check_alignment(prices: pd.DataFrame) -> dict:
    """
    Verify all assets share one date index with no missing business days.
    Business-day-aware: a Friday -> Monday gap is 1 business day apart and
    is NOT flagged as irregular; only an actual skipped business day
    (holiday not accounted for, or a real data gap) is.
    """
    idx = prices.index
    freq = pd.infer_freq(idx)
    if len(idx) > 1:
        bdays_apart = np.array([
            np.busday_count(idx[i - 1].date(), idx[i].date()) for i in range(1, len(idx))
        ])
        irregular_positions = np.where(bdays_apart != 1)[0] + 1  # index of the date AFTER the gap
        irregular_dates = [idx[i].date().isoformat() for i in irregular_positions[:10]]
    else:
        irregular_dates = []
    return {
        "n_dates": len(idx),
        "n_assets": prices.shape[1],
        "inferred_freq": freq,
        "n_irregular_gaps": len(irregular_dates) if len(idx) <= 1 else int((bdays_apart != 1).sum()),
        "irregular_gap_dates": irregular_dates,
    }


def missing_data_report(prices: pd.DataFrame) -> pd.Series:
    """% of observations missing per asset, worst first."""
    return (prices.isna().mean() * 100).sort_values(ascending=False)


def _max_consecutive_true(mask: pd.Series) -> int:
    if not mask.any():
        return 0
    run_id = (~mask).cumsum()
    return int(mask.groupby(run_id).sum().max())


def fill_missing(prices: pd.DataFrame, max_gap: int = 5):
    """
    Forward-fill gaps up to `max_gap` observations (a short halt/holiday
    mismatch is safe to bridge). Any asset with a LONGER gap is flagged,
    not silently filled -- a multi-week gap usually means the asset
    shouldn't be in this universe for this period at all (delisting,
    late IPO, bad feed), and forward-filling it would hand the optimizer
    fabricated zero-return days that quietly suppress its measured risk.
    """
    filled = prices.ffill(limit=max_gap)
    flagged = []
    for col in prices.columns:
        max_run = _max_consecutive_true(prices[col].isna())
        if max_run > max_gap:
            flagged.append((col, max_run))
    return filled, flagged


def detect_stale_prices(prices: pd.DataFrame, max_consecutive: int = 5) -> dict:
    """Flag assets with long runs of a completely unchanged price."""
    flagged = {}
    for col in prices.columns:
        unchanged = prices[col].diff().eq(0.0)
        max_run = _max_consecutive_true(unchanged)
        if max_run >= max_consecutive:
            flagged[col] = max_run
    return flagged


def detect_return_outliers(log_ret: pd.DataFrame, z_thresh: float = 6.0) -> pd.DataFrame:
    """Flag single-day log-return moves beyond z_thresh standard deviations
    per asset -- candidates for a bad print or an unadjusted corporate
    action rather than genuine volatility."""
    z = (log_ret - log_ret.mean()) / log_ret.std()
    hits = []
    flags = z.abs() > z_thresh
    for col in log_ret.columns:
        for d in log_ret.index[flags[col]]:
            hits.append({"asset": col, "date": d.date().isoformat(),
                         "log_return": float(log_ret.loc[d, col]), "z_score": float(z.loc[d, col])})
    return pd.DataFrame(hits, columns=["asset", "date", "log_return", "z_score"])


def data_quality_report(prices: pd.DataFrame, max_gap: int = 5, stale_run: int = 5,
                         outlier_z: float = 6.0, verbose: bool = True) -> dict:
    """Runs all four checks and returns a single report dict. Does NOT
    mutate prices -- call clean_prices() separately once you've reviewed
    what got flagged."""
    align = check_alignment(prices)
    missing = missing_data_report(prices)
    _, gap_flags = fill_missing(prices, max_gap=max_gap)
    stale_flags = detect_stale_prices(prices, max_consecutive=stale_run)

    log_ret = np.log(prices / prices.shift(1)).dropna(how="all")
    outliers = detect_return_outliers(log_ret, z_thresh=outlier_z)

    report = {
        "alignment": align,
        "missing_pct_by_asset": missing[missing > 0].to_dict(),
        "unfillable_gaps": gap_flags,
        "stale_price_runs": stale_flags,
        "return_outliers": outliers,
        "is_clean": (align["n_irregular_gaps"] == 0 and len(missing[missing > 0]) == 0
                     and len(gap_flags) == 0 and len(stale_flags) == 0 and len(outliers) == 0),
    }

    if verbose:
        print(f"[data_quality] {align['n_assets']} assets x {align['n_dates']} dates, "
              f"freq={align['inferred_freq']}, {align['n_irregular_gaps']} irregular gap(s)")
        if report["missing_pct_by_asset"]:
            print(f"  Missing data: {report['missing_pct_by_asset']}")
        if gap_flags:
            print(f"  Gaps too long to safely fill (>{max_gap} obs): {gap_flags}")
        if stale_flags:
            print(f"  Stale price runs (>= {stale_run} unchanged): {stale_flags}")
        if len(outliers):
            print(f"  Return outliers (|z| > {outlier_z}):")
            for _, row in outliers.iterrows():
                print(f"    {row['asset']} on {row['date']}: log-return {row['log_return']:.3f} "
                      f"(z={row['z_score']:.1f}) -- check for an unadjusted split/spinoff or bad print")
        if report["is_clean"]:
            print("  All checks passed -- panel is aligned, complete, and free of stale/outlier flags.")
    return report


def clean_prices(prices: pd.DataFrame, max_gap: int = 5, drop_flagged_assets: bool = True):
    """
    Applies the remediation the report recommends:
      - forward-fills gaps up to max_gap
      - drops (or just reports, if drop_flagged_assets=False) any asset
        whose longest gap exceeds max_gap -- these need a human decision,
        not an automatic fill
    Returns (clean_prices, dropped_assets).
    """
    filled, gap_flags = fill_missing(prices, max_gap=max_gap)
    dropped = [name for name, _ in gap_flags]
    if drop_flagged_assets and dropped:
        filled = filled.drop(columns=dropped)
    return filled, dropped
