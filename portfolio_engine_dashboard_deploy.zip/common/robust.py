"""
common/robust.py
-------------------
Point-estimate mean-variance optimization has a well-documented failure
mode in live markets: it doesn't just use your mu/Sigma estimates, it
actively HUNTS for whichever combination of them looks best -- which
means it disproportionately bets on whichever assets your estimation
error happened to flatter (Michaud called this "error maximization").
Small, statistically meaningless changes in the input estimates can
produce completely different, often highly concentrated weights. That
instability -- not the math being "wrong" -- is the usual reason a
backtested optimizer disappoints in live trading.

Two independent, standard remedies, both implemented here:

  1. Equilibrium-anchored mu (market_allocator/black_litterman.py,
     wired into common/backtest.py as mu_method="equilibrium") --
     doesn't estimate mu from noisy trailing returns at all; it's a
     function of Sigma and market weights, which are far more stable
     period to period than a rolling sample mean.
  2. Resampled ("Michaud") optimization -- instead of solving once on
     the point estimates, bootstrap many plausible return histories
     consistent with the same (mu, Sigma), re-solve on each, and
     average the resulting weights. Estimation noise gets averaged
     out instead of being chased into a corner solution.
"""
import numpy as np


def resampled_weights(allocator, mu: np.ndarray, cov: np.ndarray, n_obs: int,
                       n_resamples: int = 200, seed: int = None) -> np.ndarray:
    """
    Michaud (1998) resampled efficiency, simplified:
      for b in 1..n_resamples:
        draw a synthetic n_obs-observation return sample from N(mu, cov)
        re-estimate (mu_b, cov_b) from that sample
        solve the allocator on (mu_b, cov_b)
      return the AVERAGE of all resulting weight vectors

    This directly targets the instability problem: any single resample
    can still land on a concentrated corner solution, but corner
    solutions driven by noise point in different (partly offsetting)
    directions across resamples, while the genuine signal in mu/Sigma
    reinforces across all of them. The average is typically far more
    diversified and far less sensitive to small input perturbations
    than the single point-estimate solution.

    Cost: n_resamples solver calls instead of 1 -- use a smaller
    n_resamples (e.g. 50) for a quick check, more (200-500) for a
    production decision.
    """
    rng = np.random.default_rng(seed)
    n = len(mu)
    weight_sum = np.zeros(n)
    n_success = 0

    for _ in range(n_resamples):
        sample = rng.multivariate_normal(mu / 252.0, cov / 252.0, size=n_obs)  # daily-scale draw
        mu_b = sample.mean(axis=0) * 252.0
        cov_b = np.cov(sample, rowvar=False) * 252.0
        cov_b = 0.5 * (cov_b + cov_b.T)
        # guard against a degenerate/near-singular bootstrap draw
        cov_b += np.eye(n) * 1e-8
        try:
            if getattr(allocator, "objective_type", None) == "min_cvar":
                w_b = allocator.optimize(mu_b, cov_b, scenario_returns=sample)
            else:
                w_b = allocator.optimize(mu_b, cov_b)
            weight_sum += w_b
            n_success += 1
        except Exception:
            continue  # skip a resample the solver couldn't handle; average over the rest

    if n_success == 0:
        raise RuntimeError("resampled_weights: every bootstrap resample failed to solve")
    w_avg = weight_sum / n_success
    return w_avg / w_avg.sum()


def weight_perturbation_distance(w_a: np.ndarray, w_b: np.ndarray) -> float:
    """L1 distance between two weight vectors -- 0 = identical portfolios,
    2 = completely disjoint (no overlap at all). Used to measure how much
    a small input perturbation moves the resulting portfolio: a stable
    method should show a small distance; a fragile one, a large one."""
    return float(np.abs(w_a - w_b).sum())


def effective_n(weights: np.ndarray) -> float:
    """Effective number of positions (inverse Herfindahl index). An
    equal-weighted N-asset portfolio scores N; a portfolio concentrated
    in one name scores ~1. A quick diversification/concentration gauge."""
    hhi = np.sum(weights ** 2)
    return float(1.0 / hhi) if hhi > 0 else 0.0
