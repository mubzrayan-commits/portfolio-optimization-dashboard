"""
common/backtest.py
--------------------
Walk-forward backtest engine (shared by both allocators).

At each rebalance date:
  1. Take the trailing `lookback` window of log returns.
  2. Clean the covariance matrix (RMT / Ledoit-Wolf / raw sample).
  3. Estimate mu (annualized mean return) -- either the naive trailing
     mean ("historical") or an equilibrium-anchored estimate
     ("equilibrium", Black-Litterman's Pi = delta*Sigma@w_mkt with no
     view blended in). Equilibrium mu is a function of Sigma and (mostly
     static) market weights, not of the noisy trailing return sample --
     see robustness_demo.py for how much more stable this makes the
     resulting weights, rebalance to rebalance.
  4. Solve the allocator for new weights (optionally via Michaud
     resampling instead of a single point-estimate solve -- see
     common/robust.py).
  5. Charge transaction costs on turnover.
  6. Hold the position until the next rebalance, compounding log returns.

This is intentionally simple (no slippage model beyond a flat bps cost, no
intraday fills) -- it exists to let you SEE whether the pipeline behaves
correctly end-to-end and to compare cleaning methods / objectives against
each other and against an equal-weight benchmark, not to be a production
execution simulator.
"""
import numpy as np
import pandas as pd

from . import returns as R
from . import covariance as C
from . import robust as RB


def rolling_backtest(prices: pd.DataFrame, allocator, lookback: int = 126,
                      rebalance_freq: int = 21, transaction_cost_bps: float = 10.0,
                      cov_method: str = "rmt", periods_per_year: int = 252,
                      mu_method: str = "historical", market_weights: np.ndarray = None,
                      delta: float = 2.5, use_resampling: bool = False, n_resamples: int = 100,
                      seed: int = 0):
    """
    mu_method: "historical" (trailing sample mean, the classic noisy
        estimate) or "equilibrium" (Black-Litterman Pi -- a function of
        Sigma and market_weights, essentially immune to sampling noise
        in the mean).
    market_weights: required for mu_method="equilibrium"; defaults to
        equal weight if not supplied (a reasonable stand-in absent real
        market-cap data -- in production, pass actual free-float caps).
    use_resampling: if True, each rebalance is solved via Michaud
        resampling (common/robust.py) instead of a single point-estimate
        solve -- more robust, costs n_resamples solver calls per rebalance.

    Returns (port_log_ret: pd.Series, weights_history: list[(date, np.ndarray)],
              diagnostics: list[dict])
    """
    from market_allocator.black_litterman import implied_equilibrium_returns

    log_ret = R.log_returns(prices)
    dates = log_ret.index
    n_assets = prices.shape[1]

    if mu_method == "equilibrium" and market_weights is None:
        market_weights = np.ones(n_assets) / n_assets

    weights_history = []
    diagnostics = []
    port_returns = []
    prev_weights = np.zeros(n_assets)

    t = lookback
    while t < len(dates):
        window = log_ret.iloc[t - lookback:t]

        if cov_method == "rmt":
            cov, diag = C.rmt_denoise(window, return_diagnostics=True)
        elif cov_method == "ledoit_wolf":
            cov, shrinkage = C.ledoit_wolf_shrinkage(window)
            diag = {"shrinkage": shrinkage}
        elif cov_method == "sample":
            cov = C.sample_covariance(window)
            cov = C.nearest_psd(cov)
            diag = {}
        else:
            raise ValueError(f"Unknown cov_method: {cov_method}")

        cov_annual = cov * periods_per_year
        diag["condition_number"] = C.condition_number(cov_annual)

        if mu_method == "historical":
            mu = window.mean().values * periods_per_year
        elif mu_method == "equilibrium":
            mu = implied_equilibrium_returns(cov_annual, market_weights, delta=delta)
        else:
            raise ValueError(f"Unknown mu_method: {mu_method}")
        diag["mu_method"] = mu_method
        diag["mu"] = mu.copy()

        if use_resampling:
            w = RB.resampled_weights(allocator, mu, cov_annual, n_obs=lookback,
                                      n_resamples=n_resamples, seed=seed)
        elif getattr(allocator, "objective_type", None) == "min_cvar":
            w = allocator.optimize(mu, cov_annual, scenario_returns=window.values)
        else:
            w = allocator.optimize(mu, cov_annual)

        turnover = float(np.abs(w - prev_weights).sum())
        cost = turnover * (transaction_cost_bps / 10000.0)
        diag["turnover"] = turnover
        diag["cost_drag"] = cost
        diag["effective_n"] = RB.effective_n(w)

        end_t = min(t + rebalance_freq, len(dates))
        period_log_ret = log_ret.iloc[t:end_t].values @ w
        if len(period_log_ret) > 0:
            period_log_ret = period_log_ret.copy()
            period_log_ret[0] -= cost  # one-time drag applied at rebalance

        port_returns.extend(period_log_ret.tolist())
        weights_history.append((dates[t], w.copy()))
        diagnostics.append({"date": dates[t], **diag})

        prev_weights = w
        t += rebalance_freq

    port_ret_series = pd.Series(port_returns, index=dates[lookback:lookback + len(port_returns)],
                                 name="portfolio_log_return")
    return port_ret_series, weights_history, diagnostics


def equal_weight_benchmark(prices: pd.DataFrame, lookback: int = 126) -> pd.Series:
    log_ret = R.log_returns(prices)
    n = prices.shape[1]
    w = np.ones(n) / n
    bench = log_ret.iloc[lookback:].values @ w
    return pd.Series(bench, index=log_ret.index[lookback:], name="equal_weight_log_return")


def performance_summary(port_log_ret: pd.Series, periods_per_year: int = 252,
                         risk_free_rate: float = 0.0) -> dict:
    total_log_ret = port_log_ret.sum()
    total_return = float(np.exp(total_log_ret) - 1.0)
    ann_ret = float(np.exp(port_log_ret.mean() * periods_per_year) - 1.0)
    ann_vol = float(port_log_ret.std() * np.sqrt(periods_per_year))
    sharpe = (ann_ret - risk_free_rate) / ann_vol if ann_vol > 1e-12 else float("nan")

    cum = np.exp(port_log_ret.cumsum())
    running_max = cum.cummax()
    drawdown = (cum - running_max) / running_max
    max_dd = float(drawdown.min())

    # simple t-stat on mean daily log return vs zero -- "is there a statistical edge?"
    n = len(port_log_ret)
    t_stat = float(port_log_ret.mean() / (port_log_ret.std() / np.sqrt(n))) if n > 1 else float("nan")

    return {
        "total_return": total_return,
        "annualized_return": ann_ret,
        "annualized_vol": ann_vol,
        "sharpe_ratio": sharpe,
        "max_drawdown": max_dd,
        "t_stat_mean_return": t_stat,
        "n_periods": n,
    }
