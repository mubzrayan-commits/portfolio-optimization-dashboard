"""
common/covariance.py
---------------------
Stage 2 of the pipeline: Robust Covariance Matrix Estimation ("cleaning").

When N (asset count) approaches T (observation count), the raw sample
covariance matrix is dominated by noise ("eigenvalue dressing") and is
often singular or ill-conditioned. Two cleaning methods are implemented:

  1. RMT / Marchenko-Pastur denoising -- eigen-decompose the correlation
     matrix, identify eigenvalues that fall inside the theoretical noise
     band, and shrink them to their average (preserving trace / total
     variance) while keeping the "signal" eigenvectors untouched.
  2. Ledoit-Wolf shrinkage -- an analytic shrinkage of the sample
     covariance toward a structured target (scikit-learn implementation).

Both are followed by a PSD projection so the result is always safe to feed
into a quadratic optimizer.
"""
import numpy as np
import pandas as pd
from sklearn.covariance import LedoitWolf


def sample_covariance(returns: pd.DataFrame) -> np.ndarray:
    return returns.cov().values


def ledoit_wolf_shrinkage(returns: pd.DataFrame):
    """Returns (shrunk_covariance, shrinkage_intensity)."""
    lw = LedoitWolf().fit(returns.values)
    return lw.covariance_, lw.shrinkage_


def marchenko_pastur_bounds(n_assets: int, n_obs: int, sigma2: float = 1.0):
    """
    lambda_+/- = sigma^2 * (1 +/- sqrt(N/T))^2
    The theoretical support of eigenvalues of a PURELY RANDOM correlation
    matrix with the same N/T ratio. Anything empirical falling inside this
    band is statistically indistinguishable from noise.
    """
    q = n_assets / n_obs
    lambda_plus = sigma2 * (1 + np.sqrt(q)) ** 2
    lambda_minus = sigma2 * (1 - np.sqrt(q)) ** 2
    return lambda_minus, lambda_plus


def nearest_psd(cov: np.ndarray, epsilon: float = 1e-10) -> np.ndarray:
    """Clip any negative/near-zero eigenvalues so the matrix is strictly PSD
    and safely invertible (guards the downstream QP solver against failures)."""
    cov_sym = (cov + cov.T) / 2.0
    eigvals, eigvecs = np.linalg.eigh(cov_sym)
    eigvals_clipped = np.clip(eigvals, epsilon, None)
    cov_psd = eigvecs @ np.diag(eigvals_clipped) @ eigvecs.T
    return (cov_psd + cov_psd.T) / 2.0


def condition_number(cov: np.ndarray) -> float:
    eigvals = np.linalg.eigvalsh(cov)
    return float(eigvals.max() / max(eigvals.min(), 1e-14))


def rmt_denoise(returns: pd.DataFrame, sigma2: float = 1.0, return_diagnostics: bool = False):
    """
    Marchenko-Pastur / RMT covariance cleaning.
      1. Work on the CORRELATION matrix (unit variance) so the MP law applies.
      2. Eigen-decompose; eigenvalues below lambda_+ are treated as noise and
         replaced by their common average (trace-preserving shrinkage).
      3. Rescale the diagonal back to exactly 1.0 (it's a correlation matrix).
      4. Reconstruct covariance using the original asset volatilities.
      5. Project to the nearest PSD matrix as a numerical safety net.

    Returns the cleaned covariance matrix (np.ndarray). Pass
    return_diagnostics=True to also get a dict with the noise-eigenvalue
    count and the MP band, e.g. for the "how much did we clean" report.
    """
    T, N = returns.shape
    corr = returns.corr().values
    std = returns.std().values

    eigvals, eigvecs = np.linalg.eigh(corr)
    order = np.argsort(eigvals)[::-1]
    eigvals, eigvecs = eigvals[order], eigvecs[:, order]

    lambda_minus, lambda_plus = marchenko_pastur_bounds(N, T, sigma2=sigma2)

    is_noise = eigvals < lambda_plus
    eigvals_clean = eigvals.copy()
    n_noise = int(is_noise.sum())
    if 0 < n_noise < N:
        eigvals_clean[is_noise] = eigvals[is_noise].mean()

    corr_clean = eigvecs @ np.diag(eigvals_clean) @ eigvecs.T
    d = np.sqrt(np.clip(np.diag(corr_clean), 1e-14, None))
    corr_clean = corr_clean / np.outer(d, d)
    np.fill_diagonal(corr_clean, 1.0)

    cov_clean = nearest_psd(corr_clean * np.outer(std, std))

    if return_diagnostics:
        diag = {
            "n_assets": N, "n_obs": T, "n_noise_eigenvalues": n_noise,
            "lambda_minus": lambda_minus, "lambda_plus": lambda_plus,
            "raw_eigenvalues": eigvals, "q_ratio": N / T,
        }
        return cov_clean, diag
    return cov_clean
