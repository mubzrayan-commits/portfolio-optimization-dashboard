"""
common/returns.py
------------------
Stage 1 of the pipeline: Ingestion & Return Mapping.

R_i,t = ln(P_i,t / P_i,t-1)   (log return -- time-additive)
r_i,t = P_i,t / P_i,t-1 - 1   (arithmetic/simple return -- portfolio-additive)

Both are implemented, with explicit conversions between the two, because
different downstream stages need different spaces:
  - covariance / RMT cleaning -> log returns (time-additive, better statistical
    properties, approx. normal for daily horizons)
  - portfolio-level aggregation (w @ r) -> arithmetic returns (a portfolio's
    simple return is the weight-average of its holdings' simple returns; a
    portfolio's LOG return is NOT the weighted average of log returns)
"""
import numpy as np
import pandas as pd


def log_returns(prices: pd.DataFrame) -> pd.DataFrame:
    """R_t = ln(P_t / P_{t-1}) for every column (asset)."""
    if (prices <= 0).any().any():
        raise ValueError("Non-positive prices found; log returns undefined.")
    return np.log(prices / prices.shift(1)).dropna(how="all")


def arithmetic_returns(prices: pd.DataFrame) -> pd.DataFrame:
    """r_t = P_t / P_{t-1} - 1 for every column (asset)."""
    return prices.pct_change().dropna(how="all")


def log_to_arithmetic(log_ret: pd.DataFrame) -> pd.DataFrame:
    """r = e^R - 1"""
    return np.exp(log_ret) - 1.0


def arithmetic_to_log(arith_ret: pd.DataFrame) -> pd.DataFrame:
    """R = ln(1 + r)"""
    return np.log1p(arith_ret)


def total_return(prices: pd.Series) -> float:
    """Cumulative (holding-period) total return over the full series."""
    return float(prices.iloc[-1] / prices.iloc[0] - 1.0)


def cumulative_log_return(log_ret: pd.DataFrame) -> pd.Series:
    """Sum of log returns == ln(P_end / P_start) -- the time-additivity property."""
    return log_ret.sum()


def cumulative_return_series(log_ret: pd.DataFrame) -> pd.DataFrame:
    """Running cumulative arithmetic total return through time, from log returns."""
    return np.exp(log_ret.cumsum()) - 1.0


def annualize_return(mean_daily_log_ret: float, periods_per_year: int = 252) -> float:
    return float(np.exp(mean_daily_log_ret * periods_per_year) - 1.0)


def annualize_vol(daily_vol: float, periods_per_year: int = 252) -> float:
    return float(daily_vol * np.sqrt(periods_per_year))


def portfolio_arithmetic_return(weights: np.ndarray, arith_ret_row: np.ndarray) -> float:
    """A portfolio's simple return IS the weight-average of holding simple returns."""
    return float(weights @ arith_ret_row)


def self_check(prices: pd.DataFrame, verbose: bool = True) -> bool:
    """
    Verifies, on real numbers, that:
      1) log returns are time-additive:  sum(R_t) == ln(P_T / P_0)
      2) log <-> arithmetic conversions round-trip exactly
      3) total_return() agrees with the arithmetic-return chain-linked product
    Raises AssertionError on any mismatch. Returns True if everything checks out.
    """
    lr = log_returns(prices)
    ar = arithmetic_returns(prices)

    for col in prices.columns:
        lhs = lr[col].sum()
        rhs = np.log(prices[col].iloc[-1] / prices[col].iloc[0])
        assert abs(lhs - rhs) < 1e-8, f"[FAIL] time-additivity broke for {col}: {lhs} vs {rhs}"

        chain_linked = (1.0 + ar[col]).prod() - 1.0
        direct = total_return(prices[col])
        assert abs(chain_linked - direct) < 1e-8, f"[FAIL] total return mismatch for {col}"

    lr2 = arithmetic_to_log(ar)
    assert np.allclose(lr.values, lr2.values, atol=1e-8), "[FAIL] log<->arithmetic round-trip broke"

    ar2 = log_to_arithmetic(lr)
    assert np.allclose(ar.values, ar2.values, atol=1e-8), "[FAIL] arithmetic<->log round-trip broke"

    if verbose:
        print("[returns.self_check] PASSED:")
        print("  - log-return time-additivity: sum(R_t) == ln(P_T/P_0)  [OK]")
        print("  - total_return() == chain-linked arithmetic returns    [OK]")
        print("  - log <-> arithmetic round-trip is exact               [OK]")
    return True
