"""
schedule_runner.py
--------------------
How this pipeline actually runs "on a schedule" in practice. Two patterns,
both using only the Python standard library (no extra installs needed):

  PATTERN A -- cron / task scheduler calls a single entry point.
    This is the recommended pattern for production: cron (Linux/Mac),
    Task Scheduler (Windows), or a cloud scheduler (see README "Where to
    run this") triggers `python schedule_runner.py --engine market` on a
    timer. The process runs once, logs its result, and exits. Nothing
    needs to stay resident in memory.

  PATTERN B -- a long-running loop (for a VM / container you keep alive).
    Useful in a dev sandbox or a small server where you don't have cron
    access. Implemented with stdlib `sched` -- no APScheduler dependency.

Both patterns call the SAME `run_rebalance()` function, which is the only
piece you'd point at a real data feed (see the `# <-- swap this` marker).
"""
import argparse
import json
import logging
import os
import sched
import sys
import time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np

from common import returns as R
from common import covariance as C
from common import backtest as BT
from market_allocator.optimizer import MarketAllocator
from altasset_allocator.optimizer import AltAssetAllocator, unsmooth_panel

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "rebalance_log.txt")
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[logging.FileHandler(LOG_PATH), logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("rebalance")


def load_market_prices():
    """
    <-- swap this for a real data pull -->
    e.g. yfinance.download(tickers, period="2y") on a machine WITH network
    access, or a Bloomberg/Refinitiv/broker API call. Must return a
    DataFrame of adjusted close prices, columns = tickers, index = dates.
    This offline demo regenerates the same synthetic universe every call.
    """
    from market_allocator.demo import simulate_market_prices
    return simulate_market_prices()


def load_altasset_navs():
    """<-- swap this for your fund admin / NAV statement feed -->"""
    from altasset_allocator.demo import simulate_true_quarterly_returns, apply_appraisal_smoothing
    import pandas as pd
    with open(os.path.join(os.path.dirname(__file__), "altasset_allocator", "config.json")) as f:
        cfg = json.load(f)
    true_panel = simulate_true_quarterly_returns(cfg["assets"])
    phis = {"PRIVATE_EQUITY_FUND": 0.55, "PRIVATE_CREDIT_FUND": 0.45, "REAL_ESTATE_NAV": 0.65,
            "SMALL_BIZ_STAKE_A": 0.50, "SMALL_BIZ_STAKE_B": 0.50,
            "LIQUID_BOND_SLEEVE": 0.0, "LIQUID_EQUITY_SLEEVE": 0.0}
    observed = pd.DataFrame({a: apply_appraisal_smoothing(true_panel[a], phis[a]) for a in cfg["assets"]})
    return observed, cfg


def run_rebalance(engine: str, lookback: int = 126, cov_method: str = "rmt"):
    """One rebalance cycle: pull data -> clean covariance -> optimize -> log
    the resulting weights. This is exactly what a cron job / scheduler
    should call. Returns the weights dict so a caller (or a downstream
    execution/order-management step) can act on them."""
    log.info(f"Starting {engine} rebalance run (lookback={lookback}, cov_method={cov_method})")

    if engine == "market":
        with open(os.path.join(os.path.dirname(__file__), "market_allocator", "config.json")) as f:
            config = json.load(f)
        prices = load_market_prices()
        config["assets"] = list(prices.columns)
        config["sector_map"], config["sector_caps"] = {}, {}

        log_ret = R.log_returns(prices).iloc[-lookback:]
        mu = log_ret.mean().values * 252
        cov = C.rmt_denoise(log_ret) * 252 if cov_method == "rmt" else C.sample_covariance(log_ret) * 252
        cov = C.nearest_psd(cov)

        allocator = MarketAllocator(config)
        weights = allocator.optimize(mu, cov)
        result = dict(zip(config["assets"], weights.round(4).tolist()))

    elif engine == "altasset":
        observed, cfg = load_altasset_navs()
        unsmoothed, _ = unsmooth_panel(observed)
        mu = unsmoothed.mean().values * 4
        cov = C.nearest_psd(C.sample_covariance(unsmoothed))
        allocator = AltAssetAllocator(cfg)
        weights = allocator.optimize(mu, cov)
        result = dict(zip(cfg["assets"], weights.round(4).tolist()))

    else:
        raise ValueError(f"Unknown engine: {engine} (use 'market' or 'altasset')")

    log.info(f"Rebalance complete: {json.dumps(result)}")
    return result


# ---------------- PATTERN B: stdlib long-running loop -------------------------
def run_forever(engine: str, interval_seconds: int):
    """
    Example cadences:
      daily rebalance check   -> interval_seconds = 24*3600
      weekly (Monday) style   -> run this in a wrapper that checks weekday
      monthly rebalance       -> better handled by cron/cloud scheduler
                                  (fixed intervals drift against calendar
                                  months); shown here for illustration only.
    """
    scheduler = sched.scheduler(time.time, time.sleep)

    def _tick():
        try:
            run_rebalance(engine)
        except Exception:
            log.exception("Rebalance run failed")
        scheduler.enter(interval_seconds, 1, _tick)

    log.info(f"Starting long-running loop for '{engine}', every {interval_seconds}s. Ctrl+C to stop.")
    scheduler.enter(0, 1, _tick)
    scheduler.run()


if __name__ == "__main__":
    # default behavior: single run (Pattern A -- this is what cron should call).
    # To try Pattern B locally:  python schedule_runner.py --engine market --loop --interval 5
    parser = argparse.ArgumentParser(description="Run one rebalance cycle (cron-friendly by default).")
    parser.add_argument("--engine", choices=["market", "altasset"], default="market")
    parser.add_argument("--lookback", type=int, default=126)
    parser.add_argument("--cov-method", choices=["rmt", "sample"], default="rmt")
    parser.add_argument("--loop", action="store_true", help="run continuously (Pattern B, demo only)")
    parser.add_argument("--interval", type=int, default=10, help="seconds between runs, --loop mode")
    args = parser.parse_args()

    if args.loop:
        run_forever(args.engine, args.interval)
    else:
        run_rebalance(args.engine, args.lookback, args.cov_method)

# ------------------------------------------------------------------------
# Crontab example (production Pattern A) -- runs every Monday at 06:00,
# i.e. a weekly rebalance check for the market engine:
#
#   0 6 * * 1  cd /path/to/portfolio_engine && \
#              /usr/bin/python3 schedule_runner.py --engine market >> outputs/cron.log 2>&1
#
# Monthly (1st of month, 06:00), alt-asset engine (quarterly NAV cadence,
# but you may still want a monthly check/log):
#
#   0 6 1 * *  cd /path/to/portfolio_engine && \
#              /usr/bin/python3 schedule_runner.py --engine altasset >> outputs/cron.log 2>&1
# ------------------------------------------------------------------------
