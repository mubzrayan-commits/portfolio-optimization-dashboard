"""
data_quality_demo.py
-----------------------
Demonstrates the Stage-1 "data optimization" layer against data that has
the exact problems real feeds have. Starts from the same clean synthetic
universe the market-allocator demo uses, deliberately injects three
realistic defects into a COPY of it, shows the checks catching all three,
cleans it, and re-verifies the result is safe to hand to Stage 1 (returns)
and Stage 2 (covariance cleaning).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd

from common import data_quality as DQ
from common import returns as R
from market_allocator.demo import simulate_market_prices


def inject_defects(prices: pd.DataFrame, seed: int = 3):
    """Corrupts a copy with three independent, realistic problems:
      1. A 3-week missing-data gap in one asset (e.g. a late data-vendor feed)
      2. A 8-day stale run in another (e.g. a halted / thinly-traded name)
      3. A single-day 10x price jump in a third (an UNADJUSTED stock split --
         exactly the failure mode the brief's Stage 1 warning is about)
    """
    rng = np.random.default_rng(seed)
    corrupted = prices.copy()
    assets = list(prices.columns)

    gap_asset = assets[0]
    gap_start = 200
    corrupted.loc[corrupted.index[gap_start:gap_start + 15], gap_asset] = np.nan

    stale_asset = assets[1]
    stale_start = 400
    stale_value = corrupted.loc[corrupted.index[stale_start], stale_asset]
    corrupted.loc[corrupted.index[stale_start:stale_start + 8], stale_asset] = stale_value

    split_asset = assets[2]
    split_day = 600
    # simulate an unadjusted 4-for-1 split: price drops 4x overnight with no
    # return adjustment applied (a real feed would normally back-adjust this)
    corrupted.loc[corrupted.index[split_day]:, split_asset] = \
        corrupted.loc[corrupted.index[split_day]:, split_asset] / 4.0

    return corrupted, {"gap_asset": gap_asset, "stale_asset": stale_asset, "split_asset": split_asset}


def main():
    print("=" * 70)
    print("DATA OPTIMIZATION DEMO (Stage 1 alignment / quality checks)")
    print("=" * 70)

    prices = simulate_market_prices()
    print(f"\nStarting from the clean {prices.shape[1]}-asset synthetic universe.")
    print("\n--- Quality report on the CLEAN data (baseline) ---")
    DQ.data_quality_report(prices)

    corrupted, defects = inject_defects(prices)
    print(f"\nInjected 3 defects: missing gap in {defects['gap_asset']}, "
          f"stale run in {defects['stale_asset']}, unadjusted split in {defects['split_asset']}")

    print("\n--- Quality report on the CORRUPTED data ---")
    report = DQ.data_quality_report(corrupted)

    assert defects["gap_asset"] in report["unfillable_gaps"] or \
           any(a == defects["gap_asset"] for a, _ in report["unfillable_gaps"]), \
           "the injected gap should have been flagged as too long to safely fill"
    assert defects["stale_asset"] in report["stale_price_runs"], \
           "the injected stale run should have been flagged"
    assert defects["split_asset"] in set(report["return_outliers"]["asset"]), \
           "the injected unadjusted split should have shown up as a return outlier"
    print("\n[Verification] all 3 injected defects were caught by the automated checks: True")

    # ---- remediate: fill short/borderline gaps, drop assets with gaps too long to trust ----
    cleaned, dropped = DQ.clean_prices(corrupted, max_gap=5, drop_flagged_assets=True)
    print(f"\nCleaning: dropped {dropped} (gap exceeded the safe-fill threshold); "
          f"{cleaned.shape[1]} of {corrupted.shape[1]} assets remain")
    print("Note: the unadjusted-split asset is NOT auto-fixed here on purpose -- a 4x price break\n"
          "needs a human to confirm it's really a split (and back-adjust it) rather than a genuine\n"
          "crash; the report exists to make you look, not to silently guess.")

    print("\n--- Quality report AFTER cleaning (split asset excluded for this check) ---")
    cleaned_ex_split = cleaned.drop(columns=[defects["split_asset"]], errors="ignore")
    final_report = DQ.data_quality_report(cleaned_ex_split)

    # ---- prove the cleaned panel is now safe for Stage 1 (returns) ----
    R.self_check(cleaned_ex_split)
    print("\n[Verification] cleaned panel passes returns.self_check(): True")
    print(f"[Verification] gap defect resolved (asset dropped): "
          f"{defects['gap_asset']} not in columns = {defects['gap_asset'] not in cleaned_ex_split.columns}")
    print(f"[Verification] stale-price flag still present on {defects['stale_asset']}: "
          f"{defects['stale_asset'] in final_report['stale_price_runs']}  "
          f"(deliberately NOT auto-remediated -- a stale run needs a human call on whether\n"
          f"  the feed was actually halted, not an automatic fill/drop)")


if __name__ == "__main__":
    main()
